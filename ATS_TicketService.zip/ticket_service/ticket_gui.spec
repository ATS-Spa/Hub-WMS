# ticket_gui.spec
# Compila con: pyinstaller ticket_gui.spec

block_cipher = None

a = Analysis(
    ['ticket_gui.py'],
    pathex=[],
    binaries=[],
    datas=[
        # Includi tutti i moduli del servizio
        ('config_manager.py',  '.'),
        ('sheets_handler.py',  '.'),
        ('mail_handler.py',    '.'),
        ('ticket_service.py',  '.'),
    ],
    hiddenimports=[
        'win32com',
        'win32com.client',
        'win32com.server',
        'pywintypes',
        'pythoncom',
        'google.oauth2.service_account',
        'google.auth.transport.requests',
        'googleapiclient.discovery',
        'googleapiclient.http',
        'cryptography.fernet',
        'schedule',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['matplotlib', 'numpy', 'PIL', 'scipy'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='ATS_TicketService',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,          # no console window
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon='ticket.ico',      # opzionale
    version_file=None,
    uac_admin=False,
)

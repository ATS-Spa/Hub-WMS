"""
ticket_service.py
Loop principale del servizio ticket ATS.
Può girare standalone (python ticket_service.py) o essere avviato dal GUI.
"""
import time
import threading
import logging
import sys
from datetime import datetime

import config_manager as cfg
import sheets_handler as sh
import mail_handler   as mh

# ── Logging ────────────────────────────────────────────────────────────────
logger = logging.getLogger('TicketService')


def setup_logging(log_callback=None):
    """Configura logging su file + callback opzionale per GUI."""
    from pathlib import Path
    import os
    log_dir = Path(os.getenv('APPDATA', '.')) / 'ATS_TicketService' / 'logs'
    log_dir.mkdir(parents=True, exist_ok=True)
    log_file = log_dir / f"service_{datetime.now().strftime('%Y%m')}.log"

    handlers = [logging.FileHandler(log_file, encoding='utf-8')]
    if log_callback:
        class CallbackHandler(logging.Handler):
            def emit(self, record):
                log_callback(self.format(record))
        cb = CallbackHandler()
        cb.setFormatter(logging.Formatter('%(asctime)s %(message)s', '%H:%M:%S'))
        handlers.append(cb)

    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s [%(levelname)s] %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S',
        handlers=handlers,
        force=True
    )


def log(msg: str):
    logger.info(msg)


# ── Stato del servizio ─────────────────────────────────────────────────────
_running   = False
_thread    = None
_svc_obj   = None  # riferimento al SheetsService


class TicketService:
    def __init__(self, log_callback=None):
        self.log_cb   = log_callback or (lambda m: None)
        self.svc      = None   # Google Sheets service
        self.sheet_id = ''
        self._stop    = threading.Event()

    def _log(self, msg: str):
        logger.info(msg)
        self.log_cb(msg)

    def _load_config(self):
        config = cfg.load_config()
        sa_path   = config.get('service_account_json', '')
        sheet_id  = config.get('sheet_id', '')

        if not sa_path:
            raise ValueError("Percorso Service Account JSON non configurato.")

        self.svc = sh.get_service(sa_path)

        # Se sheet_id non è nel config locale, prova a leggerlo da Drive
        if not sheet_id:
            config_drive_id = config.get('config_drive_file_id', '')
            if config_drive_id:
                self._log("[SVC] sheet_id non trovato in config locale, cerco su Drive...")
                try:
                    sheet_id = sh.fetch_sheet_id_from_drive(sa_path, config_drive_id)
                    if sheet_id:
                        self._log(f"[SVC] sheet_id trovato su Drive: {sheet_id}")
                        cfg.set_value('sheet_id', sheet_id)
                except Exception as e:
                    self._log(f"[SVC] Warning fetch sheet_id da Drive: {e}")

        if not sheet_id:
            raise ValueError("sheet_id non trovato. Avvia prima il modulo web e crea il primo ticket.")

        self.sheet_id = sheet_id
        # Assicura colonne header complete
        try:
            sh.ensure_sheet_headers(self.svc, self.sheet_id)
        except Exception as e:
            self._log(f"[SVC] Warning ensure headers: {e}")

        return cfg.load_config()

    def _send_mail(self, to: str, subject: str, body: str,
                   reply_to_entry_id: str = '', reply_to_email: str = '',
                   cc: str = '') -> str:
        config = cfg.load_config()
        use_smtp     = config.get('use_smtp', False)
        from_address = config.get('outlook_mail_address', '')

        if use_smtp:
            return mh.send_via_smtp(
                to=to, subject=subject, body=body,
                smtp_host=config.get('smtp_host', ''),
                smtp_port=int(config.get('smtp_port', 587)),
                smtp_user=config.get('smtp_user', ''),
                smtp_password=config.get('smtp_password', ''),
                smtp_from=config.get('smtp_from', from_address),
                use_tls=config.get('smtp_use_tls', True),
                log_fn=self._log
            )
        else:
            return mh.send_via_outlook(
                to=to, subject=subject, body=body,
                from_address=from_address,
                reply_to_entry_id=reply_to_entry_id,
                reply_to_email=reply_to_email,
                cc=cc,
                log_fn=self._log
            )

    def _process_new_tickets(self, config: dict):
        """Manda mail per i ticket non ancora notificati:
           1. Conferma all'utente che ha aperto il ticket
           2. Notifica IT a mail_notifiche
        """
        try:
            unprocessed = sh.read_unprocessed_tickets(self.svc, self.sheet_id)
            if not unprocessed:
                return

            mail_it   = config.get('mail_notifiche', config.get('outlook_mail_address', ''))
            from_addr = config.get('outlook_mail_address', '')

            for t in unprocessed:
                try:
                    autore_email = t.get('AutoreEmail', '').strip()

                    # ── 1 sola mail a utente+IT → thread unico ──
                    # Subject fisso con ID per raggruppamento in tutti i client
                    subj = f"[{t['ID']}] {t.get('Titolo','')}"
                    body_it = mh.build_ticket_body(t, tipo='nuovo', for_user=False)[1]

                    # Destinatari: autore + IT (se diversi)
                    destinatari = autore_email if autore_email else mail_it
                    if mail_it and mail_it.lower() != (autore_email or '').lower():
                        destinatari = autore_email + '; ' + mail_it if autore_email else mail_it

                    entry_id = self._send_mail(destinatari, subj, body_it)
                    self._log(f"[SVC] ✉ Ticket → {destinatari} | RFC: {entry_id[:30] if entry_id else 'n/a'}")
                    time.sleep(2)

                    # Salva RFC MessageID per thread futuro
                    sh.mark_mail_sent(self.svc, self.sheet_id, t['ID'], entry_id)
                    self._log(f"[SVC] ✅ Ticket {t['ID']} notificato")
                    time.sleep(1)

                except Exception as e:
                    self._log(f"[SVC] ❌ Errore notifica {t['ID']}: {e}")

        except Exception as e:
            self._log(f"[SVC] Errore processo nuovi ticket: {e}")

    def _process_updates(self, config: dict):
        """
        Legge le note pendenti dal tab Notes (MailInviata=NO)
        e manda una mail per ogni nota non ancora notificata.
        """
        try:
            # Leggi note non ancora notificate
            pending_notes = sh.read_pending_notes(self.svc, self.sheet_id)
            if not pending_notes:
                return

            mail_it = config.get('mail_notifiche', config.get('outlook_mail_address', ''))
            from_addr = config.get('outlook_mail_address', '')

            # Raggruppa per ticket per leggere EntryID una volta sola
            tickets_cache = {}

            for note in pending_notes:
                try:
                    tid        = note['ticket_id']
                    note_txt   = note['testo']
                    updater    = note['autore']
                    row_num    = note['row_num']

                    # Carica ticket se non in cache
                    if tid not in tickets_cache:
                        all_t = sh.read_all_tickets(self.svc, self.sheet_id)
                        t = next((x for x in all_t if x['ID']==tid), None)
                        tickets_cache[tid] = t
                    else:
                        t = tickets_cache[tid]

                    if not t:
                        self._log(f"[SVC] ⚠ Ticket {tid} non trovato per nota riga {row_num}")
                        sh.mark_note_sent(self.svc, self.sheet_id, row_num)
                        continue

                    autore_email = t.get('AutoreEmail','').strip()
                    entry_id     = t.get('MessageID','').strip()
                    is_valid_eid = (entry_id and len(entry_id) > 20 and
                                   entry_id.upper() not in ('PENDING_UPDATE','NO','SI',''))

                    self._log(f"[SVC] 📝 Nota {tid} riga {row_num} | EntryID: {'OK' if is_valid_eid else 'MANCANTE'} | da: {updater}")

                    # Subject FISSO uguale al ticket originale → thread garantito
                    subj = f"[{tid}] {t.get('Titolo','')}"
                    _, body_nota = mh.build_ticket_body(t, tipo='nota',
                        note_testo=note_txt, updater=updater, for_user=False)

                    # 1 sola mail con autore+IT come destinatari
                    dest_list = []
                    if autore_email: dest_list.append(autore_email)
                    if mail_it and mail_it.lower() != (autore_email or '').lower():
                        dest_list.append(mail_it)
                    destinatari = '; '.join(dest_list) if dest_list else mail_it

                    self._send_mail(destinatari, subj, body_nota,
                                   reply_to_entry_id=entry_id if is_valid_eid else '')
                    self._log(f"[SVC] ✉ Nota → {destinatari}")

                    # Segna nota come notificata
                    sh.mark_note_sent(self.svc, self.sheet_id, row_num)
                    self._log(f"[SVC] ✅ Nota {tid} riga {row_num} notificata")
                    time.sleep(1)

                except Exception as e:
                    self._log(f"[SVC] ❌ Errore nota riga {note.get('row_num','?')}: {e}")

            # Dopo aver processato tutte le note, resetta PENDING_UPDATE sui ticket
            # riportando MailInviata a SI
            processed_tids = set(n['ticket_id'] for n in pending_notes)
            for tid in processed_tids:
                try:
                    t = tickets_cache.get(tid)
                    if t:
                        entry_id = t.get('MessageID','').strip()
                        sh.mark_mail_sent(self.svc, self.sheet_id, tid, entry_id)
                except Exception:
                    pass

        except Exception as e:
            self._log(f"[SVC] Errore processo note: {e}")

    def _process_inbox_replies(self, config: dict):
        """Legge risposte email e le aggiunge come note ai ticket."""
        try:
            from_address = config.get('outlook_mail_address', '')
            if not from_address or config.get('use_smtp', False):
                return  # Lettura inbox disponibile solo con Outlook

            replies = mh.read_inbox_replies(
                from_address=from_address,
                since_hours=int(config.get('polling_interval_sec', 120)) // 3600 + 1,
                log_fn=self._log
            )

            for reply in replies:
                tid  = reply['ticket_id']
                body = reply['body']
                sender = reply['sender']
                if not tid or not body.strip():
                    continue
                try:
                    # Verifica che il ticket esista nel tab Tickets attivo
                    row_check = sh.find_ticket_row(self.svc, self.sheet_id, tid)
                    if row_check < 0:
                        self._log(f"[SVC] ⚠ {tid} non in Tickets (archiviato/inesistente) — ignorato")
                        continue

                    # Usa sender_name se disponibile (evita DN Exchange)
                    sender_display = reply.get('sender_name') or reply.get('sender','')
                    if not sender_display or sender_display.startswith('/O='):
                        sender_display = reply.get('sender','')
                    ok = sh.append_note_to_ticket(
                        self.svc, self.sheet_id,
                        ticket_id=tid,
                        autore=f"📧 {sender_display}",
                        testo=body.strip(),
                        mail_inviata='SI'
                    )
                    if ok:
                        self._log(f"[SVC] 📬 Risposta aggiunta a {tid} da {sender_display}")
                except Exception as e:
                    self._log(f"[SVC] Errore aggiunta nota inbox per {tid}: {e}")

        except Exception as e:
            self._log(f"[SVC] Errore processo inbox: {e}")

    def run_once(self):
        """Esegue un singolo ciclo di controllo."""
        try:
            config = self._load_config()
            self._log(f"[SVC] 🔍 Ciclo controllo — {datetime.now().strftime('%H:%M:%S')}")
            self._process_new_tickets(config)
            self._process_updates(config)
            self._process_inbox_replies(config)
            self._process_archive(config)
        except Exception as e:
            self._log(f"[SVC] ❌ Errore ciclo: {e}")

    def _process_archive(self, config: dict):
        """Archivia automaticamente i ticket con stato Chiuso o Risolto."""
        try:
            all_t = sh.read_all_tickets(self.svc, self.sheet_id)
            stati_archivio = ['Chiuso', 'Risolto']
            for t in all_t:
                if t.get('Stato','') in stati_archivio and t.get('ID',''):
                    self._log(f"[SVC] 📦 Archivio ticket {t['ID']} (stato: {t['Stato']})")
                    sh.archive_ticket(self.svc, self.sheet_id, t['ID'])
        except Exception as e:
            self._log(f"[SVC] Errore archivio: {e}")

    def _auto_close_outlook_popup(self):
        """Thread che chiude automaticamente il popup di conflitto Outlook."""
        import ctypes
        user32 = ctypes.windll.user32
        while not self._stop.is_set():
            try:
                # Cerca finestra con titolo "Microsoft Outlook"
                hwnd = user32.FindWindowW('MsoDialog', None)
                if not hwnd:
                    hwnd = user32.FindWindowW(None, 'Microsoft Outlook')
                if hwnd:
                    # Simula click su OK (Enter)
                    import ctypes
                    VK_RETURN = 0x0D
                    WM_KEYDOWN = 0x0100
                    WM_KEYUP   = 0x0101
                    user32.PostMessageW(hwnd, WM_KEYDOWN, VK_RETURN, 0)
                    user32.PostMessageW(hwnd, WM_KEYUP, VK_RETURN, 0)
            except Exception:
                pass
            self._stop.wait(timeout=3)

    def run_loop(self):
        """Loop principale con intervallo configurabile."""
        self._log("[SVC] ▶ Servizio avviato")
        # Thread che chiude automaticamente popup Outlook
        popup_killer = threading.Thread(target=self._auto_close_outlook_popup, daemon=True)
        popup_killer.start()
        # Attesa iniziale
        self._log("[SVC] ⏳ Attesa avvio sistema (60s)...")
        self._stop.wait(timeout=60)
        while not self._stop.is_set():
            self.run_once()
            interval = cfg.get('polling_interval_sec', 120)
            self._log(f"[SVC] 💤 Prossimo controllo tra {interval}s")
            self._stop.wait(timeout=interval)
        self._log("[SVC] ⏹ Servizio fermato")

    def start(self):
        self._stop.clear()
        t = threading.Thread(target=self.run_loop, daemon=True)
        t.start()
        return t

    def stop(self):
        self._stop.set()


# ── Entry point standalone ─────────────────────────────────────────────────
if __name__ == '__main__':
    setup_logging()
    svc = TicketService(log_callback=print)
    try:
        svc.run_loop()
    except KeyboardInterrupt:
        svc.stop()
        print("\n[SVC] Interrotto dall'utente")

"""
mail_handler.py
Invio mail via Outlook win32com con thread nativo.
"""
import re
import smtplib
import ssl
import time
import uuid
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta


# ── TROVA ACCOUNT ──────────────────────────────────────────────────────────

def _find_account(ns, from_address: str, log_fn=None):
    """Trova l'account Outlook per from_address."""
    for acc in ns.Accounts:
        try:
            if (acc.SmtpAddress or '').lower() == from_address.lower():
                return acc
        except Exception:
            continue
    # Fallback parziale
    for acc in ns.Accounts:
        try:
            if from_address.lower() in (acc.SmtpAddress or '').lower():
                return acc
        except Exception:
            continue
    if log_fn: log_fn(f"[MAIL] ⚠ Account {from_address} non trovato, uso default")
    return None


def _find_sent_item(ns, subject_fragment: str, from_address: str, log_fn=None):
    """
    Cerca la mail appena inviata nella Posta Inviata dello store di from_address.
    Cerca SOLO nello store dell'account corretto.
    """
    # Trova store dell'account corretto
    target_store = None
    for store in ns.Stores:
        try:
            for acc in ns.Accounts:
                if (acc.DeliveryStore and
                    acc.DeliveryStore.StoreID == store.StoreID and
                    (acc.SmtpAddress or '').lower() == from_address.lower()):
                    target_store = store
                    break
            if target_store:
                break
        except Exception:
            continue

    # Cerca in tutti gli store, priorità a quello di from_address
    all_stores = list(ns.Stores)
    if target_store and target_store in all_stores:
        all_stores.remove(target_store)
        all_stores.insert(0, target_store)

    for store in all_stores:
        try:
            sent = store.GetDefaultFolder(5)  # olFolderSentMail
            items = sent.Items
            items.Sort('[SentOn]', True)
            for i, item in enumerate(items):
                if i > 20:
                    break
                try:
                    if subject_fragment in (item.Subject or ''):
                        return item
                except Exception:
                    continue
        except Exception:
            continue
    return None


# ── INVIO MAIL ─────────────────────────────────────────────────────────────

def send_via_outlook(
    to: str,
    subject: str,
    body: str,
    from_address: str,
    reply_to_entry_id: str = '',
    reply_to_email: str = '',
    cc: str = '',
    log_fn=None
) -> str:
    """
    Invia mail via Outlook.
    Se reply_to_entry_id è fornito, crea una vera Reply a quella mail
    (stesso thread garantito da Outlook).
    Restituisce l'EntryID della mail inviata.
    """
    try:
        import win32com.client
        import pythoncom
        pythoncom.CoInitialize()

        # Connessione a Outlook (Click-to-Run compatibile)
        outlook = None
        ns = None
        last_err = None
        for method in ['GetActiveObject', 'Dispatch']:
            try:
                if method == 'GetActiveObject':
                    outlook = win32com.client.GetActiveObject('Outlook.Application')
                else:
                    outlook = win32com.client.Dispatch('Outlook.Application')
                ns = outlook.GetNamespace('MAPI')
                _ = len(ns.Stores)
                if log_fn: log_fn(f"[MAIL] Outlook connesso via {method}")
                break
            except Exception as e:
                last_err = e; outlook = None; ns = None
        if not ns:
            raise RuntimeError(f"Outlook non disponibile: {last_err}")
        account = _find_account(ns, from_address, log_fn)
        if account:
            if log_fn: log_fn(f"[MAIL] Account: {account.SmtpAddress}")

        mail = None

        # ── Thread: usa In-Reply-To MAPI per collegare le mail ──
        if reply_to_entry_id:
            try:
                mail_tmp = None
                is_rfc_id = reply_to_entry_id.startswith('<')

                if is_rfc_id:
                    # MessageID RFC: crea nuova mail con In-Reply-To MAPI
                    # Questo funziona indipendentemente dall'account Outlook
                    if log_fn: log_fn(f"[MAIL] Thread RFC: {reply_to_entry_id[:40]}")
                else:
                    # EntryID Outlook: prova Reply() nativa
                    try:
                        original_item = ns.GetItemFromID(reply_to_entry_id)
                        mail_tmp = original_item.Reply()
                        mail_tmp.To = to
                        mail_tmp.Subject = subject
                        mail_tmp.Body = body + '\n'
                        if account:
                            mail_tmp.SendUsingAccount = account
                        if log_fn: log_fn(f"[MAIL] Reply nativa EntryID: {reply_to_entry_id[:20]}")
                        mail = mail_tmp
                    except Exception as e:
                        if log_fn: log_fn(f"[MAIL] Reply EntryID fallita ({e})")
                        mail_tmp = None

                # Se non abbiamo ancora la mail (RFC o fallback), crea nuova con headers
                if mail is None and mail_tmp is None:
                    pass  # verrà creata sotto
                elif mail_tmp is not None:
                    mail = mail_tmp

            except Exception as e:
                if log_fn: log_fn(f"[MAIL] Errore thread setup: {e}")
                mail = None

        # ── Altrimenti crea nuova mail dallo store dell'account corretto ──
        if mail is None:
            mail = None
            if account:
                try:
                    # Crea mail direttamente dalla Outbox dell'account sapmailer
                    # così parte sicuramente da quell'account
                    store = account.DeliveryStore
                    drafts = store.GetDefaultFolder(16)  # olFolderDrafts = 16
                    mail = drafts.Items.Add()
                    mail.To = to
                    mail.Subject = subject
                    mail.Body = body
                    mail.SendUsingAccount = account
                except Exception as e:
                    if log_fn: log_fn(f"[MAIL] Draft store fallito ({e}), uso CreateItem")
                    mail = None
            if mail is None:
                mail = outlook.CreateItem(0)
                mail.To = to
                mail.Subject = subject
                mail.Body = body
                if account:
                    mail.SendUsingAccount = account

        # Imposta In-Reply-To e References per thread (RFC MessageID)
        if reply_to_entry_id and reply_to_entry_id.startswith('<'):
            try:
                PA = mail.PropertyAccessor
                PA.SetProperty('http://schemas.microsoft.com/mapi/proptag/0x1042001E', reply_to_entry_id)
                PA.SetProperty('http://schemas.microsoft.com/mapi/proptag/0x1039001E', reply_to_entry_id)
                if log_fn: log_fn(f"[MAIL] In-Reply-To impostato: {reply_to_entry_id[:40]}")
            except Exception as e:
                if log_fn: log_fn(f"[MAIL] Warning In-Reply-To: {e}")

        # CC
        if cc:
            try:
                mail.CC = cc
            except Exception:
                pass

        # Reply-To header
        if reply_to_email:
            try:
                mail.ReplyRecipients.Add(reply_to_email)
            except Exception:
                pass

        mail.Send()
        time.sleep(4)  # attesa sync Exchange

        # Recupera prima il MessageID RFC (header standard, portabile)
        # poi fallback su EntryID Outlook
        entry_id = ''
        for attempt in range(3):
            sent_item = _find_sent_item(ns, subject[:25], from_address, log_fn)
            if sent_item:
                try:
                    PR_MSGID = 'http://schemas.microsoft.com/mapi/proptag/0x1035001E'
                    rfc_id = sent_item.PropertyAccessor.GetProperty(PR_MSGID)
                    if rfc_id and rfc_id.startswith('<'):
                        entry_id = rfc_id
                        if log_fn: log_fn(f"[MAIL] MessageID RFC: {entry_id}")
                        break
                except Exception:
                    pass
                try:
                    entry_id = sent_item.EntryID
                    if log_fn: log_fn(f"[MAIL] EntryID: {entry_id[:20]}")
                    break
                except Exception:
                    pass
            if not entry_id:
                time.sleep(2)

        if log_fn: log_fn(f"[MAIL] ✉ Inviata → {to} | {subject[:50]}")
        return entry_id

    except ImportError:
        raise RuntimeError("win32com non disponibile.")
    except Exception as e:
        raise RuntimeError(f"Errore Outlook: {e}")
    finally:
        try:
            import pythoncom as _pc
            _pc.CoUninitialize()
        except Exception:
            pass


def send_via_smtp(
    to: str, subject: str, body: str,
    smtp_host: str, smtp_port: int, smtp_user: str, smtp_password: str,
    smtp_from: str, use_tls: bool = True,
    in_reply_to: str = '', references: str = '',
    log_fn=None
) -> str:
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From']    = smtp_from
    msg['To']      = to
    if in_reply_to:
        msg['In-Reply-To'] = in_reply_to
        msg['References']  = (references + ' ' + in_reply_to).strip() if references else in_reply_to
    msg.attach(MIMEText(body, 'plain', 'utf-8'))
    ctx = ssl.create_default_context()
    if use_tls:
        with smtplib.SMTP(smtp_host, smtp_port) as s:
            s.ehlo(); s.starttls(context=ctx); s.login(smtp_user, smtp_password)
            s.sendmail(smtp_from, [to], msg.as_string())
    else:
        with smtplib.SMTP_SSL(smtp_host, smtp_port, context=ctx) as s:
            s.login(smtp_user, smtp_password)
            s.sendmail(smtp_from, [to], msg.as_string())
    if log_fn: log_fn(f"[MAIL] ✉ SMTP → {to} | {subject[:50]}")
    return ''


# ── LETTURA INBOX ──────────────────────────────────────────────────────────

def read_inbox_replies(from_address: str, since_hours: int = 24, log_fn=None) -> list:
    """
    Legge risposte sia dalla Inbox che dalla Posta Inviata di from_address.
    Inbox: risposte degli utenti esterni.
    Posta Inviata: risposte manuali del dev/IT da Outlook.
    Esclude solo le notifiche automatiche del sistema.
    """
    results = []
    seen_ids = set()

    try:
        import win32com.client
        import pythoncom
        pythoncom.CoInitialize()

        # Agganciati all'istanza Outlook già aperta
        # Riprova fino a 5 minuti con attese progressive
        # Connessione a Outlook (Click-to-Run compatibile)
        outlook = None
        ns = None
        last_err = None
        for method in ['GetActiveObject', 'Dispatch']:
            try:
                if method == 'GetActiveObject':
                    outlook = win32com.client.GetActiveObject('Outlook.Application')
                else:
                    outlook = win32com.client.Dispatch('Outlook.Application')
                ns = outlook.GetNamespace('MAPI')
                _ = len(ns.Stores)
                if log_fn: log_fn(f"[MAIL] Outlook connesso via {method}")
                break
            except Exception as e:
                last_err = e; outlook = None; ns = None
        if not ns:
            raise RuntimeError(f"Outlook non disponibile: {last_err}")

        # Trova store dell'account corretto
        target_store = None
        for store in ns.Stores:
            try:
                for acc in ns.Accounts:
                    if (acc.DeliveryStore and
                        acc.DeliveryStore.StoreID == store.StoreID and
                        (acc.SmtpAddress or '').lower() == from_address.lower()):
                        target_store = store
                        break
                if target_store: break
            except Exception:
                continue

        since = datetime.now() - timedelta(hours=since_hours)
        since_str = since.strftime('%m/%d/%Y %H:%M %p')

        # Controlla Inbox (6) e Posta Inviata (5)
        folders_to_check = []
        if target_store:
            try: folders_to_check.append(('inbox', target_store.GetDefaultFolder(6)))
            except Exception: pass
            try: folders_to_check.append(('sent', target_store.GetDefaultFolder(5)))
            except Exception: pass
        else:
            try: folders_to_check.append(('inbox', ns.GetDefaultFolder(6)))
            except Exception: pass

        for folder_type, folder in folders_to_check:
            try:
                filter_field = '[ReceivedTime]' if folder_type == 'inbox' else '[SentOn]'
                try:
                    items = folder.Items.Restrict(f"{filter_field} >= '{since_str}'")
                except Exception:
                    items = folder.Items

                for item in items:
                    try:
                        entry_id = getattr(item, 'EntryID', '') or ''
                        if entry_id in seen_ids:
                            continue

                        subject = getattr(item, 'Subject', '') or ''
                        if 'TKT-' not in subject.upper():
                            continue

                        ticket_id = _extract_ticket_id(subject)
                        if not ticket_id:
                            continue

                        subj_lower = subject.lower()
                        is_reply = any(subj_lower.startswith(p) for p in ['re:', 'rif:', 'r:', 'aw:'])

                        # Inbox: solo risposte (Re: ecc.)
                        if folder_type == 'inbox' and not is_reply:
                            continue

                        # Leggi mittente
                        sender_raw  = getattr(item, 'SenderEmailAddress', '') or ''
                        sender_name = getattr(item, 'SenderName', '') or ''
                        sender = sender_raw
                        if sender_raw.startswith('/O=') or sender_raw.startswith('/o='):
                            try:
                                PR_SMTP = 'http://schemas.microsoft.com/mapi/proptag/0x39FE001E'
                                smtp_addr = item.Sender.PropertyAccessor.GetProperty(PR_SMTP)
                                sender = smtp_addr if smtp_addr else sender_name
                            except Exception:
                                sender = sender_name

                        # Escludi notifiche automatiche (mittente=sistema + non è reply)
                        is_from_service = (sender.lower() == from_address.lower() or
                                          from_address.lower() in sender.lower())
                        if is_from_service and not is_reply:
                            continue

                        # Inbox: solo non lette
                        if folder_type == 'inbox':
                            if not getattr(item, 'UnRead', False):
                                continue

                        body_raw = getattr(item, 'Body', '') or ''
                        body = _clean_reply_body(body_raw)  # applica sempre
                        if not body.strip():
                            continue

                        # Autore display
                        display_name = sender_name if sender_name else sender
                        if display_name.startswith('/O=') or display_name.startswith('/o='):
                            display_name = sender
                        if folder_type == 'sent':
                            display_name = sender_name or from_address

                        received = getattr(item, 'ReceivedTime', None) or getattr(item, 'SentOn', None)

                        seen_ids.add(entry_id)
                        results.append({
                            'ticket_id':   ticket_id,
                            'subject':     subject,
                            'body':        body,
                            'sender':      sender,
                            'sender_name': display_name,
                            'received_at': str(received) if received else '',
                            'entry_id':    entry_id,
                            'folder':      folder_type,
                        })

                        if folder_type == 'inbox':
                            try:
                                item.UnRead = False
                                item.Save()
                            except Exception:
                                pass

                    except Exception as e:
                        if log_fn: log_fn(f"[MAIL] Warning item {folder_type}: {e}")
                        continue

            except Exception as e:
                if log_fn: log_fn(f"[MAIL] Errore cartella {folder_type}: {e}")

        if log_fn and results:
            log_fn(f"[MAIL] 📬 {len(results)} risposta/e (inbox+sent)")

    except ImportError:
        if log_fn: log_fn("[MAIL] win32com non disponibile")
    except Exception as e:
        if log_fn: log_fn(f"[MAIL] Errore lettura mail: {e}")
    finally:
        try:
            import pythoncom as _pc
            _pc.CoUninitialize()
        except Exception:
            pass
    return results

def _extract_ticket_id(subject: str) -> str:
    m = re.search(r'TKT-[A-Z0-9]+', subject.upper())
    return m.group(0) if m else ''


def _clean_reply_body(body: str) -> str:
    """
    Estrae solo il testo della risposta, scartando il quoted thread.
    Funziona sia per Inbox che Posta Inviata.
    """
    lines = body.split('\n')
    clean = []
    for line in lines:
        s = line.strip()
        # Stop ai separatori tipici di Outlook/Exchange in italiano e inglese
        if any(s.startswith(p) for p in [
            '> ', '-----', '___',
            'Da:', 'From:', 'De:',
            'Inviato:', 'Sent:', 'Envoyé:',
            'A:', 'To:', 'À:',
            'Oggetto:', 'Subject:', 'Objet:',
            'Il giorno', 'On ', 'Le ',
            'Cc:', 'CC:',
        ]):
            break
        # Stop a linee di separazione
        if s.startswith('---') and len(s) > 6:
            break
        if s.startswith('___') and len(s) > 6:
            break
        # Stop al pattern Exchange "Da: Nome <email>" anche senza a capo
        if 'Da:' in s and '@' in s:
            break
        clean.append(line)
    return '\n'.join(clean).strip()


# ── TEMPLATE MAIL ──────────────────────────────────────────────────────────

def build_ticket_body(ticket: dict, tipo: str = 'nuovo', note_testo: str = '',
                      updater: str = '', for_user: bool = False) -> tuple:
    tid   = ticket.get('ID', '')
    title = ticket.get('Titolo', '')
    proj  = ticket.get('Progetto', '')
    prio  = ticket.get('Priorita', '')
    stato = ticket.get('Stato', '')
    autore       = ticket.get('Autore', '')
    autore_email = ticket.get('AutoreEmail', '')
    assegnato    = ticket.get('Assegnato', '')
    data_ap      = ticket.get('DataApertura', '')
    desc         = ticket.get('Descrizione', '')
    sep = '\u2500' * 50

    if tipo == 'nuovo':
        subject = f'[{tid}] Nuovo ticket: {title}'
        if for_user:
            body = (f'Ciao {autore},\n\nla tua richiesta \u00e8 stata registrata.\n\n'
                    f'{sep}\nNumero: {tid}\nTitolo: {title}\nProgetto: {proj}\n'
                    f'Tipo: {ticket.get("Tipo","")}\nPriorit\u00e0: {prio}\nData: {_fmt_date(data_ap)}\n')
            if desc: body += f'\nMotivazione:\n{desc}\n'
            body += f'\n{sep}\nRispondi a questa mail per aggiornare il ticket.\n\nWMS Hub \u00b7 Ticket Manager ATS'
        else:
            body = (f'NUOVO TICKET APERTO\n{sep}\n\nID: {tid}\nTitolo: {title}\nProgetto: {proj}\n'
                    f'Tipo: {ticket.get("Tipo","")}\nPriorit\u00e0: {prio}\nStato: {stato}\n'
                    f'Aperto da: {autore} <{autore_email}>\nData: {_fmt_date(data_ap)}\n')
            if desc: body += f'\nDescrizione:\n{desc}\n'
            body += f'\n{sep}\nWMS Hub \u00b7 Ticket Manager ATS'

    elif tipo == 'nota':
        subject = f'[{tid}] Aggiornamento: {title}'
        if for_user:
            body = (f'Ciao {autore},\n\n{updater} ha aggiunto una nota al tuo ticket:\n\n'
                    f'{sep}\n{note_testo}\n{sep}\n\n'
                    f'Ticket: {tid} | Stato: {stato}\n\n'
                    f'Rispondi a questa mail per rispondere.\n\nWMS Hub \u00b7 Ticket Manager ATS')
        else:
            body = (f'NOTA AGGIUNTA AL TICKET\n{sep}\n\nID: {tid}\nTitolo: {title}\n'
                    f'Autore nota: {updater}\n\nContenuto:\n{note_testo}\n\n'
                    f'{sep}\nWMS Hub \u00b7 Ticket Manager ATS')

    elif tipo == 'stato':
        subject = f'[{tid}] Stato aggiornato: {stato} \u2014 {title}'
        if for_user:
            body = (f'Ciao {autore},\n\nil tuo ticket \u00e8 stato aggiornato.\n\n'
                    f'{sep}\nID: {tid}\nTitolo: {title}\nNuovo stato: {stato}\n'
                    f'Aggiornato da: {updater}\n\n{sep}\nWMS Hub \u00b7 Ticket Manager ATS')
        else:
            body = (f'AGGIORNAMENTO STATO\n{sep}\n\nID: {tid}\nTitolo: {title}\n'
                    f'Nuovo stato: {stato}\nAggiornato da: {updater}\n\n'
                    f'{sep}\nWMS Hub \u00b7 Ticket Manager ATS')

    elif tipo == 'assegnato':
        subject = f'[{tid}] Preso in carico: {title}'
        if for_user:
            body = (f'Ciao {autore},\n\nil tuo ticket \u00e8 stato preso in carico da {assegnato}.\n\n'
                    f'{sep}\nID: {tid}\nTitolo: {title}\nAssegnato a: {assegnato}\n'
                    f'Stato: {stato}\n\n{sep}\nWMS Hub \u00b7 Ticket Manager ATS')
        else:
            body = (f'TICKET ASSEGNATO\n{sep}\n\nID: {tid}\nAssegnato a: {assegnato}\n'
                    f'Titolo: {title}\n\n{sep}\nWMS Hub \u00b7 Ticket Manager ATS')
    else:
        subject = f'[{tid}] {title}'
        body = f'Ticket: {tid}\n{sep}\nWMS Hub \u00b7 Ticket Manager ATS'

    return subject, body


def _fmt_date(iso: str) -> str:
    try:
        return datetime.fromisoformat(iso).strftime('%d/%m/%Y %H:%M')
    except Exception:
        return iso

"""
presenze_handler.py
Gestisce le notifiche email automatiche per le richieste ferie/permessi
del modulo Presenze WMS Hub.

Flusso:
1. Legge richieste_ferie.json da Drive
2. Per ogni richiesta in_attesa senza mail_inviata → manda mail al responsabile
3. Per ogni richiesta approvata/rifiutata senza mail_esito_inviata → manda mail al dipendente
4. Aggiorna il JSON con i flag mail_inviata/mail_esito_inviata
"""

import json
import re
from datetime import datetime

# Cartella Drive presenze
PRESENZE_FOLDER_ID = '1IDwOTQmrhvHsZ1hsfS9jCZZm1I0XRbNA'  # cartella JSON
RICH_FNAME         = 'richieste_ferie.json'
CONFIG_FNAME       = 'config_presenze.json'  # per risolvere email_notifiche dei co-approvatori

TIPO_LABEL = {
    'F':   'Ferie',
    'HP':  'Ore Permesso',
    '104': 'Giornata 104',
    'H104':'Ore 104',
    'CP':  'Congedo Parentale',
    'HPE': 'Ore Permesso Esami',
    'PE':  'Permesso Esami',
}

# Tipi che rappresentano una quantità di ORE (non un giorno intero): il campo
# 'tipo' per questi contiene il numero davanti alla sigla, es. '2HP' → 2 ore.
QTY_TIPI = {'HP', 'H104', 'HPE'}

SEP = '\u2500' * 50


def _fmt_date(s: str) -> str:
    """Converte YYYY-MM-DD in DD/MM/YYYY."""
    try:
        return datetime.strptime(s, '%Y-%m-%d').strftime('%d/%m/%Y')
    except Exception:
        return s or '—'


def _tipo_label(req: dict) -> str:
    code = req.get('tipo_code', '') or req.get('tipo', '')
    return TIPO_LABEL.get(code, code)


def _ore_richieste(req: dict):
    """
    Per i tipi a ore (HP/H104/HPE) estrae la quantità dal campo 'tipo'
    (es. '2HP' → '2', 'HP' nudo → '1' come da fallback storico). Ritorna
    None per i tipi a giornata intera, per cui il campo non ha senso.
    """
    code = req.get('tipo_code', '')
    if code not in QTY_TIPI:
        return None
    m = re.match(r'^([\d.]+)', str(req.get('tipo', '')))
    val = m.group(1) if m else '1'
    # Numero pulito: '1.0' → '1', '1.5' resta '1.5'
    try:
        f = float(val)
        val = str(int(f)) if f == int(f) else str(f)
    except Exception:
        pass
    return val


def _periodo(req: dict) -> str:
    dal = _fmt_date(req.get('data_dal', ''))
    al  = _fmt_date(req.get('data_al', ''))
    return dal if dal == al else f"{dal} → {al}"


# ── Drive helpers ────────────────────────────────────────────────────────────

def _load_richieste(drive_svc) -> tuple:
    """Carica richieste_ferie.json da Drive. Restituisce (data_dict, file_id)."""
    results = drive_svc.files().list(
        q=f'"{PRESENZE_FOLDER_ID}" in parents and name="{RICH_FNAME}" and trashed=false',
        fields='files(id,name)'
    ).execute()
    files = results.get('files', [])
    if not files:
        return {'richieste': []}, None

    file_id = files[0]['id']
    content = drive_svc.files().get_media(fileId=file_id).execute()
    if isinstance(content, bytes):
        content = content.decode('utf-8')
    data = json.loads(content)
    return data, file_id


def _load_users_config(drive_svc) -> dict:
    """
    Carica config_presenze.json da Drive e restituisce solo la mappa
    'users' (email di login → {is_admin, email_notifiche, ...}) — serve per
    risolvere l'email aziendale dei co-approvatori. Ritorna {} in caso di
    errore o file assente: in quel caso si ricade sull'email di login,
    esattamente come prima di questa aggiunta.
    """
    try:
        results = drive_svc.files().list(
            q=f'"{PRESENZE_FOLDER_ID}" in parents and name="{CONFIG_FNAME}" and trashed=false',
            fields='files(id,name)'
        ).execute()
        files = results.get('files', [])
        if not files:
            return {}
        content = drive_svc.files().get_media(fileId=files[0]['id']).execute()
        if isinstance(content, bytes):
            content = content.decode('utf-8')
        cfg = json.loads(content)
        return cfg.get('users', {}) or {}
    except Exception:
        return {}


def _notifica_email(login_email: str, users_cfg: dict) -> str:
    """
    Preferisce l'email aziendale (campo 'email_notifiche', impostabile nel
    modal 'Modifica Utente' quando si spunta Admin) configurata per chi si
    logga con login_email — utile perché un co-approvatore può autenticarsi
    con un account Google diverso dalla sua email di lavoro. Se non è
    configurata, usa l'email di login così com'è.
    """
    if not login_email:
        return login_email
    u = users_cfg.get(login_email) or users_cfg.get(login_email.lower())
    if u and u.get('email_notifiche'):
        return u['email_notifiche']
    return login_email


def _save_richieste(drive_svc, data: dict, file_id: str):
    """Salva richieste_ferie.json su Drive."""
    from googleapiclient.http import MediaInMemoryUpload
    body_bytes = json.dumps(data, ensure_ascii=False, indent=2).encode('utf-8')
    media = MediaInMemoryUpload(body_bytes, mimetype='application/json')
    if file_id:
        drive_svc.files().update(fileId=file_id, media_body=media).execute()
    else:
        meta = {'name': RICH_FNAME, 'parents': [PRESENZE_FOLDER_ID]}
        drive_svc.files().create(body=meta, media_body=media).execute()


# ── Template mail ────────────────────────────────────────────────────────────

def _build_mail_richiesta(req: dict) -> tuple:
    """Mail al responsabile per nuova richiesta."""
    label   = _tipo_label(req)
    periodo = _periodo(req)
    gg      = req.get('giorni_lavorativi', '?')
    dip     = req.get('dipendente_nome', '')
    resp    = req.get('responsabile_nome', '')
    sap     = req.get('dipendente_sap', '')
    plant   = req.get('dipendente_plant', '')
    note    = req.get('note', '')

    subject = f'[PRESENZE] Richiesta {label} – {dip} – {periodo}'
    ore = _ore_richieste(req)
    body = (
        f'Buongiorno {resp},\n\n'
        f'{dip} ha inviato una richiesta tramite WMS Presenze.\n\n'
        f'{SEP}\n'
        f'Tipo:      {label}\n'
        f'Periodo:   {periodo}\n'
        f'Giorni:    {gg} lavorativi\n'
    )
    if ore is not None: body += f'Ore:       {ore}\n'
    if sap:   body += f'SAP:       {sap}\n'
    if plant: body += f'Plant:     {plant}\n'
    if note:  body += f'Note:      {note}\n'
    body += (
        f'\n{SEP}\n'
        f'Puoi approvare o rifiutare direttamente dal portale WMS Presenze.\n\n'
        f'Cordiali saluti,\n{dip}\n\n'
        f'WMS Hub · Modulo Presenze ATS'
    )
    return subject, body


def _build_mail_esito(req: dict) -> tuple:
    """Mail al dipendente per esito richiesta."""
    label    = _tipo_label(req)
    periodo  = _periodo(req)
    gg       = req.get('giorni_lavorativi', '?')
    dip      = req.get('dipendente_nome', '')
    resp     = req.get('responsabile_nome', '')
    stato    = req.get('stato', '')
    nota_r   = req.get('nota_resp', '')
    approvata = stato == 'approvata'

    subject = f'[PRESENZE] {"✅ Approvata" if approvata else "❌ Rifiutata"} – {label} – {periodo}'
    ore = _ore_richieste(req)
    body = (
        f'Buongiorno {dip},\n\n'
        f'la tua richiesta è stata {"APPROVATA ✅" if approvata else "RIFIUTATA ❌"}.\n\n'
        f'{SEP}\n'
        f'Tipo:      {label}\n'
        f'Periodo:   {periodo}\n'
        f'Giorni:    {gg} lavorativi\n'
    )
    if ore is not None: body += f'Ore:       {ore}\n'
    if nota_r: body += f'Nota:      {nota_r}\n'
    if approvata:
        body += '\nLe presenze sono state aggiornate automaticamente sul foglio.\n'
    body += (
        f'\n{SEP}\n'
        f'Cordiali saluti,\n{resp}\n\n'
        f'WMS Hub · Modulo Presenze ATS'
    )
    return subject, body


# ── Processo principale ──────────────────────────────────────────────────────

def process_presenze_notifications(drive_svc, send_mail_fn, log_fn=None):
    """
    Controlla le richieste e manda le mail necessarie.

    :param drive_svc: Google Drive service (già autenticato)
    :param send_mail_fn: callable(to, subject, body) → invia mail via Outlook
    :param log_fn: callable(msg) → log
    """
    def log(msg):
        if log_fn: log_fn(msg)

    try:
        data, file_id = _load_richieste(drive_svc)
    except Exception as e:
        log(f"[PRES] Errore lettura richieste_ferie.json: {e}")
        return

    richieste = data.get('richieste', [])
    if not richieste:
        return

    # Solo se serve davvero (evita una chiamata Drive in più ad ogni ciclo
    # quando non ci sono richieste): mappa email di login → email_notifiche.
    users_cfg = _load_users_config(drive_svc)

    changed = False

    # Data attivazione servizio — richieste precedenti non vanno notificate
    from datetime import datetime as _dt
    ACTIVATION_DATE = _dt(2026, 6, 2)  # data da cui il servizio è attivo

    def _req_date(req):
        """Restituisce la data della richiesta come datetime, o None."""
        for field in ('data_richiesta', 'data_dal', 'created_at'):
            v = req.get(field, '')
            for fmt in ('%d/%m/%Y', '%Y-%m-%d', '%d-%m-%Y'):
                try:
                    return _dt.strptime(v, fmt)
                except Exception:
                    continue
        return None

    for req in richieste:
        rid   = req.get('id', '?')
        stato = req.get('stato', '')

        # ── Richieste senza flag: controlla se precedenti al servizio ──
        if req.get('mail_inviata') is None and req.get('mail_esito_inviata') is None:
            req_dt = _req_date(req)
            if req_dt and req_dt < ACTIVATION_DATE:
                # Richiesta vecchia: marca come già processata senza mandare mail
                req['mail_inviata']       = True
                req['mail_esito_inviata'] = True
                changed = True
                log(f"[PRES] ⏭ {rid} precedente al servizio — marcata come processata")
                continue

        # ── 1. Nuova richiesta in attesa → notifica responsabile ──
        if stato == 'in_attesa' and not req.get('mail_inviata'):
            # Usa email aziendale se presente, altrimenti email google
            resp_email = (req.get('responsabile_email','') or req.get('responsabile_email_google','')).strip()
            if not resp_email:
                log(f"[PRES] {rid}: nessuna email responsabile, skip")
                req['mail_inviata'] = True; changed = True
                continue
            try:
                subj, body = _build_mail_richiesta(req)
                # I co-approvatori (altri utenti Admin abilitati ad approvare
                # anche loro) vanno destinatari alla pari del responsabile
                # principale, non solo in copia: sono fotografati sulla
                # richiesta al momento dell'invio come responsabile_email_extra.
                co_approvatori = [
                    _notifica_email(e.strip(), users_cfg)
                    for e in (req.get('responsabile_email_extra', []) or [])
                    if e and e.strip()
                ]
                to_list = [resp_email] + [e for e in co_approvatori if e.lower() != resp_email.lower()]
                to_str = ';'.join(to_list)
                # CC al dipendente — usa email aziendale se disponibile
                dip_email_cc = (req.get('dipendente_email_lavoro','') or
                                req.get('dipendente_email','')).strip()
                cc_set = {e.lower(): e for e in to_list}  # per evitare doppioni to/cc
                cc_list = []
                if dip_email_cc and dip_email_cc.lower() not in cc_set:
                    cc_list.append(dip_email_cc)
                    cc_set[dip_email_cc.lower()] = dip_email_cc
                cc = ';'.join(cc_list)
                msg_id = send_mail_fn(to_str, subj, body, cc=cc)
                req['mail_inviata'] = True
                req['message_id']   = msg_id or ''  # per thread esito
                changed = True
                log(f"[PRES] ✉ Richiesta {rid} → {to_str}" + (f" CC:{cc}" if cc else ""))
            except Exception as e:
                log(f"[PRES] ❌ Errore notifica {rid}: {e}")

        # ── 2. Esito (approvata/rifiutata) → notifica dipendente ──
        if stato in ('approvata', 'rifiutata') and not req.get('mail_esito_inviata'):
            dip_email  = (req.get('dipendente_email_lavoro','') or
                          req.get('dipendente_email','')).strip()
            resp_email = (req.get('responsabile_email','') or
                          req.get('responsabile_email_google','')).strip()
            if not dip_email:
                log(f"[PRES] {rid}: nessuna email dipendente, skip")
                req['mail_esito_inviata'] = True; changed = True
                continue
            try:
                subj, body = _build_mail_esito(req)
                msg_id_orig = req.get('message_id','').strip()
                # CC: responsabile principale + co-approvatori + eventuali
                # email extra del dipendente (es. account personale diverso
                # da quello di login) — prima venivano ignorati entrambi.
                co_approvatori = [
                    _notifica_email(e.strip(), users_cfg)
                    for e in (req.get('responsabile_email_extra', []) or [])
                    if e and e.strip()
                ]
                dip_extra = [e.strip() for e in req.get('dipendente_email_extra', []) or [] if e and e.strip()]
                cc_set = {dip_email.lower()}
                cc_list = []
                for e in [resp_email] + co_approvatori + dip_extra:
                    if e and e.lower() not in cc_set:
                        cc_list.append(e)
                        cc_set.add(e.lower())
                cc = ';'.join(cc_list)
                # Risponde sullo stesso thread della richiesta originale
                send_mail_fn(dip_email, subj, body,
                            cc=cc,
                            reply_to_entry_id=msg_id_orig)
                req['mail_esito_inviata'] = True
                changed = True
                log(f"[PRES] ✉ Esito {rid} ({stato}) → {dip_email}" +
                    (f" CC:{cc}" if cc else "") +
                    (f" (thread)" if msg_id_orig else ""))
            except Exception as e:
                log(f"[PRES] ❌ Errore esito {rid}: {e}")

    # Salva solo se ci sono modifiche
    if changed:
        try:
            _save_richieste(drive_svc, data, file_id)
            log(f"[PRES] ✅ richieste_ferie.json aggiornato")
        except Exception as e:
            log(f"[PRES] ❌ Errore salvataggio: {e}")

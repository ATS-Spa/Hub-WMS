"""
ticket_service_runner.py
Avvia il servizio ticket con icona system tray.
Nessuna finestra tkinter — gira puro in background.
Avviato da Task Scheduler al login Windows.
"""
import sys
import os
import threading
import subprocess
from pathlib import Path

# Aggiungi la cartella corrente al path
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

import config_manager as cfg
from ticket_service import TicketService, setup_logging

def make_icon(color='#10b981'):
    try:
        from PIL import Image, ImageDraw
        img = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        draw.ellipse([2, 2, 62, 62], fill=color)
        draw.rectangle([20, 18, 44, 24], fill='white')
        draw.rectangle([29, 18, 35, 48], fill='white')
        return img
    except Exception:
        return None


def main():
    setup_logging(log_callback=print)

    svc = TicketService(log_callback=print)
    svc_thread = None
    stop_event = threading.Event()

    try:
        import pystray
        from PIL import Image

        def on_start(icon, item):
            nonlocal svc_thread
            if svc_thread and svc_thread.is_alive():
                print("[TRAY] Servizio già in esecuzione")
                return
            svc_thread = svc.start()
            icon.icon  = make_icon('#10b981')
            icon.title = 'ATS Ticket Service — In esecuzione ✅'
            print("[TRAY] Servizio avviato")

        def on_stop(icon, item):
            svc.stop()
            icon.icon  = make_icon('#64748b')
            icon.title = 'ATS Ticket Service — Fermo ⏹'
            print("[TRAY] Servizio fermato")

        def on_open_gui(icon, item):
            script = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'ticket_gui.py')
            subprocess.Popen([sys.executable, script])

        def on_quit(icon, item):
            svc.stop()
            stop_event.set()
            icon.stop()

        menu = pystray.Menu(
            pystray.MenuItem('▶ Avvia servizio',  on_start),
            pystray.MenuItem('⏹ Ferma servizio',  on_stop),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem('⚙ Apri configuratore', on_open_gui),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem('✕ Esci', on_quit),
        )

        icon = pystray.Icon(
            'ATS Ticket Service',
            make_icon('#64748b'),
            'ATS Ticket Service — Fermo',
            menu
        )

        # Avvia servizio automaticamente
        svc_thread = svc.start()
        icon.icon  = make_icon('#10b981')
        icon.title = 'ATS Ticket Service — In esecuzione ✅'

        print("[TRAY] Icona tray avviata — servizio in esecuzione")
        # Blocca qui fino a on_quit
        icon.run()

    except ImportError:
        # Senza pystray: loop puro
        print("[SVC] pystray non disponibile — avvio loop puro")
        try:
            svc.run_loop()
        except KeyboardInterrupt:
            svc.stop()


if __name__ == '__main__':
    main()

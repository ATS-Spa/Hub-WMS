# ATS Ticket Service

Servizio di ticketing integrato con **WMS Hub ATS** — gestisce notifiche email automatiche per i ticket aperti dal frontend web, legge le risposte dalla casella mail e le sincronizza su Google Sheets.

## Architettura

```
WMS Hub (GitHub Pages)          PC Server (Windows)
├── index.html                  ├── ticket_gui.py      ← configuratore + monitor
├── index_Tickets.html          ├── ticket_service.py  ← loop principale
└── ...altri moduli             ├── sheets_handler.py  ← Google Sheets API
                                ├── mail_handler.py    ← Outlook win32com
                                └── config_manager.py  ← config cifrata
          │                               │
          └──── Google Sheets ────────────┘
               (Tickets + Notes + Archivio)
```

## Funzionalità

- **Notifica automatica** — ogni nuovo ticket genera mail a IT + conferma all'utente
- **Thread email** — le note e risposte viaggiano sullo stesso thread della mail originale
- **Lettura risposte** — legge sia Inbox che Posta Inviata di Outlook → aggiunge come note
- **Archivio automatico** — ticket Chiusi/Risolti vengono spostati in tab separato
- **System tray** — icona nella barra di sistema (verde = attivo, grigia = fermo)
- **Task Scheduler** — avvio automatico con Windows

## Prerequisiti

- Python 3.11+
- Microsoft Outlook installato e configurato con l'account di servizio
- Google Cloud Project con Sheets API e Drive API abilitate
- Service Account Google con accesso alle cartelle Drive

## Installazione

```bash
pip install -r requirements.txt
```

## Setup Google Cloud

1. Vai su [console.cloud.google.com](https://console.cloud.google.com)
2. Seleziona il tuo progetto
3. **API & Services → Library** → abilita:
   - Google Sheets API
   - Google Drive API
4. **IAM & Admin → Service Accounts** → seleziona il service account
5. **Keys → Add Key → Create new key → JSON** → scarica il file
6. Condividi le cartelle Drive con l'email del service account (`xxx@progetto.iam.gserviceaccount.com`)

## Configurazione

Avvia il configuratore:
```bash
python ticket_gui.py
```

### Tab Google API
| Campo | Descrizione |
|-------|-------------|
| File JSON Service Account | Path al file scaricato da Google Cloud |
| Sheet ID | Lascia vuoto — viene letto automaticamente dal config su Drive |
| ID file config_tickets.json | Dall'URL del file su Drive: `/d/{ID}/` |

### Tab Outlook / Mail
| Campo | Descrizione |
|-------|-------------|
| Indirizzo email account | Email dell'account Outlook configurato come secondario |
| Email notifiche IT | Destinatario delle notifiche ticket (es. it@azienda.eu) |

### Tab Servizio
- **Intervallo polling**: ogni quanti secondi controlla (default 120s)
- **Registra in Task Scheduler**: avvio automatico al login Windows

## Struttura Google Sheets

Il servizio crea e gestisce automaticamente questi tab:

| Tab | Contenuto |
|-----|-----------|
| `Tickets` | Un ticket per riga, con stato e EntryID mail |
| `Notes` | Una nota per riga, collegata al TicketID |
| `Ticket Risolti` | Archivio ticket chiusi/risolti |
| `Note Archiviate` | Note dei ticket archiviati |

## Avvio

**Modalità GUI** (configurazione e monitor):
```bash
python ticket_gui.py
```

**Modalità servizio** (solo loop, con icona tray):
```bash
python ticket_gui.py --service
```

La modalità `--service` viene usata dal Task Scheduler — avvia il loop in background con solo l'icona nella system tray.

## Flusso email

```
Ticket aperto → mail IT + CC utente (stesso thread)
                         ↓
Dev aggiunge nota → reply sullo stesso thread
                         ↓
Utente/IT risponde dalla mail → servizio legge risposta
→ aggiunge nota su Drive → notifica reply
```

## Configurazione cifrata

La config (email, path JSON, ecc.) è salvata cifrata in:
```
%APPDATA%\ATS_TicketService\service_config.enc
```
La chiave di cifratura è in:
```
%APPDATA%\ATS_TicketService\service.key
```

## Note di sicurezza

- Il file JSON del Service Account non è incluso nel repo
- Le credenziali sono cifrate localmente con Fernet (AES-128)
- Il `CLIENT_ID` OAuth nei file HTML è pubblico per design (standard Google OAuth)
- Nessuna password o token è hardcoded nel codice

## Dipendenze principali

| Libreria | Uso |
|----------|-----|
| `google-api-python-client` | Google Sheets/Drive API |
| `google-auth` | Autenticazione Service Account |
| `pywin32` | Integrazione Outlook (win32com) |
| `pystray` | Icona system tray |
| `Pillow` | Rendering icona tray |
| `cryptography` | Cifratura config locale |

"""
config_manager.py
Gestione configurazione cifrata per il servizio ticket ATS.
"""
import json
import os
import base64
from pathlib import Path
from cryptography.fernet import Fernet

CONFIG_FILE = Path(os.getenv('APPDATA', '.')) / 'ATS_TicketService' / 'service_config.enc'
KEY_FILE    = Path(os.getenv('APPDATA', '.')) / 'ATS_TicketService' / 'service.key'

DEFAULT_CONFIG = {
    # Google
    "service_account_json": "",      # path al JSON del service account
    "sheet_id": "",                  # ID Google Sheet ticket (auto-rilevato da config_tickets.json)
    "config_drive_file_id": "",      # ID file config_tickets.json su Drive
    "drive_folder_data": "11ocsebXn-EPfhiIxTf3J6kZ3fH3xQYmf",

    # Outlook
    "outlook_mail_address": "itlogisticsata@atsgruppo.eu",  # mail account Outlook da usare
    "mail_notifiche": "itlogisticsata@atsgruppo.eu",        # destinatario notifiche

    # SMTP Exchange (opzionale, alternativa a Outlook)
    "use_smtp": False,
    "smtp_host": "",
    "smtp_port": 587,
    "smtp_user": "",
    "smtp_password": "",
    "smtp_use_tls": True,
    "smtp_from": "",

    # Servizio
    "polling_interval_sec": 120,     # ogni quanti secondi controlla
    "log_max_lines": 500,
    "autostart": False,              # avvia col PC (richiede registrazione servizio Windows)

    # Stato interno
    "last_processed_row": 1,         # ultima riga sheet processata
}


def _ensure_dir():
    CONFIG_FILE.parent.mkdir(parents=True, exist_ok=True)


def _get_or_create_key() -> bytes:
    _ensure_dir()
    if KEY_FILE.exists():
        return KEY_FILE.read_bytes()
    key = Fernet.generate_key()
    KEY_FILE.write_bytes(key)
    return key


def load_config() -> dict:
    cfg = dict(DEFAULT_CONFIG)
    if not CONFIG_FILE.exists():
        return cfg
    try:
        key = _get_or_create_key()
        fernet = Fernet(key)
        raw = CONFIG_FILE.read_bytes()
        decrypted = fernet.decrypt(raw)
        saved = json.loads(decrypted.decode('utf-8'))
        cfg.update(saved)
    except Exception as e:
        print(f"[CONFIG] Errore lettura config: {e} — uso default")
    return cfg


def save_config(cfg: dict):
    _ensure_dir()
    key = _get_or_create_key()
    fernet = Fernet(key)
    data = json.dumps(cfg, ensure_ascii=False, indent=2).encode('utf-8')
    encrypted = fernet.encrypt(data)
    CONFIG_FILE.write_bytes(encrypted)


def get(key: str, default=None):
    return load_config().get(key, default)


def set_value(key: str, value):
    cfg = load_config()
    cfg[key] = value
    save_config(cfg)

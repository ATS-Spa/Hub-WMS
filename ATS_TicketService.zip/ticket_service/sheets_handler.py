"""
sheets_handler.py
Lettura e scrittura Google Sheets via Service Account (headless, no OAuth popup).
"""
import json
import re
from datetime import datetime
from google.oauth2 import service_account
from googleapiclient.discovery import build

SCOPES = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive.readonly',
]

SHEET_NAME    = 'Tickets'
SHEET_HEADERS = [
    'ID','Titolo','Progetto','Tipo','Priorita','Stato',
    'Descrizione','Autore','AutoreEmail','Assegnato','AssegnatoEmail',
    'DataApertura','DataAggiornamento','MailInviata','MessageID'
]
# indici colonne (0-based)
COL = {h: i for i, h in enumerate(SHEET_HEADERS)}

NOTES_NAME    = 'Notes'
NOTES_HEADERS = ['TicketID','Autore','Data','Testo','MailInviata']
NCOL = {h: i for i, h in enumerate(NOTES_HEADERS)}

ARCHIVE_NAME = 'Ticket Risolti'


def _creds(sa_json_path: str):
    return service_account.Credentials.from_service_account_file(
        sa_json_path, scopes=SCOPES
    )


def get_service(sa_json_path: str):
    return build('sheets', 'v4', credentials=_creds(sa_json_path), cache_discovery=False)


def get_drive_service(sa_json_path: str):
    from googleapiclient.discovery import build as _build
    creds = service_account.Credentials.from_service_account_file(sa_json_path, scopes=SCOPES)
    return _build('drive', 'v3', credentials=creds, cache_discovery=False)


# ── Lettura config_tickets.json da Drive per ottenere sheet_id ──────────────
def fetch_sheet_id_from_drive(sa_json_path: str, config_drive_file_id: str) -> str:
    """Legge il config_tickets.json da Drive e restituisce sheet_id."""
    import requests
    creds = service_account.Credentials.from_service_account_file(sa_json_path, scopes=SCOPES)
    creds.refresh(requests.Request() if False else _token_request())
    # Usa Drive API per scaricare il file
    drive_svc = get_drive_service(sa_json_path)
    content = drive_svc.files().get_media(fileId=config_drive_file_id).execute()
    data = json.loads(content.decode('utf-8') if isinstance(content, bytes) else content)
    return data.get('sheet_id', '')


def _token_request():
    import google.auth.transport.requests
    return google.auth.transport.requests.Request()


# ── Lettura ticket dallo Sheet ───────────────────────────────────────────────
def read_all_tickets(svc, sheet_id: str) -> list[dict]:
    result = svc.spreadsheets().values().get(
        spreadsheetId=sheet_id,
        range=f'{SHEET_NAME}!A2:P'
    ).execute()
    rows = result.get('values', [])
    tickets = []
    for row in rows:
        while len(row) < len(SHEET_HEADERS):
            row.append('')
        t = {h: row[COL[h]] for h in SHEET_HEADERS}
        tickets.append(t)
    return tickets


def read_unprocessed_tickets(svc, sheet_id: str) -> list[dict]:
    """Restituisce ticket con MailInviata = 'NO' o vuoto (mai notificati)."""
    all_t = read_all_tickets(svc, sheet_id)
    return [t for t in all_t if t.get('MailInviata', '').upper() not in ('SI', 'PENDING_UPDATE')]


def read_tickets_needing_update(svc, sheet_id: str) -> list[dict]:
    """Restituisce ticket con MailInviata = 'PENDING_UPDATE'."""
    all_t = read_all_tickets(svc, sheet_id)
    return [t for t in all_t if t.get('MailInviata', '').upper() == 'PENDING_UPDATE']


def find_ticket_row(svc, sheet_id: str, ticket_id: str) -> int:
    """Restituisce il numero di riga (1-based) del ticket, -1 se non trovato."""
    all_t = read_all_tickets(svc, sheet_id)
    for i, t in enumerate(all_t):
        if t['ID'] == ticket_id:
            return i + 2  # +1 header +1 base-1
    return -1


def mark_mail_sent(svc, sheet_id: str, ticket_id: str, message_id: str = ''):
    """Segna MailInviata=SI e salva l'EntryID Outlook per il thread (campo MessageID)."""
    row_num = find_ticket_row(svc, sheet_id, ticket_id)
    if row_num < 0:
        print(f"[SH] WARN: ticket {ticket_id} non trovato per mark_mail_sent")
        return
    print(f"[SH] mark_mail_sent: {ticket_id} → riga {row_num}, EntryID={message_id[:20] if message_id else 'vuoto'}")
    # Col P = MailInviata (indice 15, lettera P), Col Q = MessageID (indice 16, lettera Q) — ma usiamo indici esistenti
    col_mail   = _col_letter(COL['MailInviata'])
    col_msgid  = _col_letter(COL['MessageID'])
    svc.spreadsheets().values().batchUpdate(
        spreadsheetId=sheet_id,
        body={'valueInputOption': 'RAW', 'data': [
            {'range': f'{SHEET_NAME}!{col_mail}{row_num}', 'values': [['SI']]},
            {'range': f'{SHEET_NAME}!{col_msgid}{row_num}', 'values': [[message_id]]},
        ]}
    ).execute()


def mark_pending_update(svc, sheet_id: str, ticket_id: str):
    """Segna il ticket come da notificare per aggiornamento."""
    row_num = find_ticket_row(svc, sheet_id, ticket_id)
    if row_num < 0:
        return
    col_mail = _col_letter(COL['MailInviata'])
    svc.spreadsheets().values().update(
        spreadsheetId=sheet_id,
        range=f'{SHEET_NAME}!{col_mail}{row_num}',
        valueInputOption='RAW',
        body={'values': [['PENDING_UPDATE']]}
    ).execute()


def append_note_to_ticket(svc, sheet_id: str, ticket_id: str, autore: str, testo: str,
                          mail_inviata: str = 'NO'):
    """Aggiunge una nota nel tab Notes e aggiorna DataAggiornamento + PENDING_UPDATE nel tab Tickets.
    mail_inviata='SI' se la nota viene da una risposta mail (già ricevuta, non va rimandata).
    mail_inviata='NO' se aggiunta dal frontend (va notificata via mail).
    """
    now = datetime.now().isoformat()
    # 1. Append riga in Notes
    svc.spreadsheets().values().append(
        spreadsheetId=sheet_id,
        range=f'{NOTES_NAME}!A1',
        valueInputOption='RAW',
        insertDataOption='INSERT_ROWS',
        body={'values': [[ticket_id, autore, now, testo, mail_inviata]]}
    ).execute()
    # 2. Aggiorna DataAggiornamento nel ticket
    # Se nota viene da mail (mail_inviata=SI) non setta PENDING_UPDATE
    row_num = find_ticket_row(svc, sheet_id, ticket_id)
    if row_num > 0:
        col_daggi = _col_letter(COL['DataAggiornamento'])
        col_mail  = _col_letter(COL['MailInviata'])
        updates = [
            {'range': f'{SHEET_NAME}!{col_daggi}{row_num}', 'values': [[now]]},
        ]
        if mail_inviata != 'SI':
            # Nota dal frontend: setta PENDING_UPDATE per notificare
            updates.append({'range': f'{SHEET_NAME}!{col_mail}{row_num}', 'values': [['PENDING_UPDATE']]})
        svc.spreadsheets().values().batchUpdate(
            spreadsheetId=sheet_id,
            body={'valueInputOption': 'RAW', 'data': updates}
        ).execute()
    return True


def ensure_sheet_headers(svc, sheet_id: str):
    """Assicura header corretti su Tickets e crea tab Notes se mancante.
    Gestisce migrazione da vecchia struttura (con campo Note) a nuova (senza).
    """
    # Tickets headers — verifica struttura e corregge se necessario
    result = svc.spreadsheets().values().get(
        spreadsheetId=sheet_id,
        range=f'{SHEET_NAME}!A1:Z1'
    ).execute()
    existing = result.get('values', [[]])[0] if result.get('values') else []

    if 'Note' in existing:
        print("[SH] Vecchia struttura rilevata (campo Note) — migrazione...")
        _migrate_remove_note_column(svc, sheet_id, existing)
    elif len(existing) > len(SHEET_HEADERS):
        # Header extra presenti — forza struttura corretta
        print(f"[SH] Header extra rilevati ({len(existing)} vs {len(SHEET_HEADERS)}) — correzione...")
        _migrate_remove_note_column(svc, sheet_id, existing)
    elif existing != SHEET_HEADERS:
        svc.spreadsheets().values().update(
            spreadsheetId=sheet_id,
            range=f'{SHEET_NAME}!A1',
            valueInputOption='RAW',
            body={'values': [SHEET_HEADERS]}
        ).execute()
    # Crea tab Notes se non esiste
    try:
        svc.spreadsheets().values().get(
            spreadsheetId=sheet_id,
            range=f'{NOTES_NAME}!A1'
        ).execute()
    except Exception:
        # Tab non esiste, crealo
        svc.spreadsheets().batchUpdate(
            spreadsheetId=sheet_id,
            body={'requests': [{'addSheet': {'properties': {'title': NOTES_NAME}}}]}
        ).execute()
    # Notes headers
    result_n = svc.spreadsheets().values().get(
        spreadsheetId=sheet_id,
        range=f'{NOTES_NAME}!A1:D1'
    ).execute()
    existing_n = result_n.get('values', [[]])[0] if result_n.get('values') else []
    if existing_n != NOTES_HEADERS:
        svc.spreadsheets().values().update(
            spreadsheetId=sheet_id,
            range=f'{NOTES_NAME}!A1',
            valueInputOption='RAW',
            body={'values': [NOTES_HEADERS]}
        ).execute()




def read_notes_for_ticket(svc, sheet_id: str, ticket_id: str) -> list[dict]:
    """Legge tutte le note del tab Notes per un ticket specifico."""
    try:
        result = svc.spreadsheets().values().get(
            spreadsheetId=sheet_id,
            range=f'{NOTES_NAME}!A2:E'
        ).execute()
        rows = result.get('values', [])
        notes = []
        for row in rows:
            while len(row) < 5:
                row.append('')
            if row[0] == ticket_id:
                notes.append({
                    'ticket_id':   row[0],
                    'autore':      row[1],
                    'data':        row[2],
                    'testo':       row[3],
                    'mail_inviata': row[4],
                })
        return notes
    except Exception:
        return []


def read_pending_notes(svc, sheet_id: str) -> list[dict]:
    """Legge tutte le note con MailInviata=NO da notificare."""
    try:
        result = svc.spreadsheets().values().get(
            spreadsheetId=sheet_id,
            range=f'{NOTES_NAME}!A2:E'
        ).execute()
        rows = result.get('values', [])
        pending = []
        for i, row in enumerate(rows):
            while len(row) < 5:
                row.append('')
            mail_inv = row[4].strip().upper()
            if mail_inv not in ('SI',):
                pending.append({
                    'row_num':     i + 2,  # +1 header +1 base-1
                    'ticket_id':   row[0],
                    'autore':      row[1],
                    'data':        row[2],
                    'testo':       row[3],
                    'mail_inviata': row[4],
                })
        return pending
    except Exception:
        return []


def mark_note_sent(svc, sheet_id: str, row_num: int):
    """Segna una nota come notificata (MailInviata=SI) nel tab Notes."""
    try:
        svc.spreadsheets().values().update(
            spreadsheetId=sheet_id,
            range=f'{NOTES_NAME}!E{row_num}',
            valueInputOption='RAW',
            body={'values': [['SI']]}
        ).execute()
    except Exception as e:
        print(f"[SH] Errore mark_note_sent riga {row_num}: {e}")


def read_all_notes(svc, sheet_id: str) -> dict:
    """Legge tutte le note e le restituisce come dict {ticket_id: [note]}."""
    try:
        result = svc.spreadsheets().values().get(
            spreadsheetId=sheet_id,
            range=f'{NOTES_NAME}!A2:D'
        ).execute()
        rows = result.get('values', [])
        notes_by_ticket = {}
        for row in rows:
            while len(row) < 5:
                row.append('')
            tid = row[0]
            if tid not in notes_by_ticket:
                notes_by_ticket[tid] = []
            notes_by_ticket[tid].append({
                'autore':       row[1],
                'data':         row[2],
                'testo':        row[3],
                'mail_inviata': row[4],
            })
        return notes_by_ticket
    except Exception:
        return {}


def _migrate_remove_note_column(svc, sheet_id: str, existing_headers: list):
    """Rimuove la colonna Note dallo Sheet Tickets e aggiusta le colonne successive."""
    try:
        # Trova colonna da rimuovere: 'Note' se presente, altrimenti colonna extra
        if 'Note' in existing_headers:
            note_col_idx = existing_headers.index('Note')
        else:
            # Rimuovi ultima colonna extra (oltre le 15 attese)
            note_col_idx = len(SHEET_HEADERS)  # indice della prima colonna extra
        print(f"[SH] Rimozione colonna indice {note_col_idx}")
        # Leggi tutti i dati
        result = svc.spreadsheets().values().get(
            spreadsheetId=sheet_id,
            range=f'{SHEET_NAME}!A1:Z'
        ).execute()
        rows = result.get('values', [])
        # Rimuovi colonna Note da ogni riga
        new_rows = []
        for row in rows:
            while len(row) <= note_col_idx:
                row.append('')
            new_row = row[:note_col_idx] + row[note_col_idx+1:]
            new_rows.append(new_row)
        # Sovrascrivi con i dati migrati
        svc.spreadsheets().values().update(
            spreadsheetId=sheet_id,
            range=f'{SHEET_NAME}!A1',
            valueInputOption='RAW',
            body={'values': new_rows}
        ).execute()
        # Assicura che header sia corretto
        svc.spreadsheets().values().update(
            spreadsheetId=sheet_id,
            range=f'{SHEET_NAME}!A1',
            valueInputOption='RAW',
            body={'values': [SHEET_HEADERS]}
        ).execute()
        print(f"[SH] ✅ Migrazione completata: rimossa colonna Note (era col {note_col_idx})")
    except Exception as e:
        print(f"[SH] ❌ Errore migrazione: {e}")



def _ensure_archive_tabs(svc, sheet_id: str):
    """Crea i tab archivio se non esistono e inizializza gli header."""
    # Ottieni lista sheet esistenti
    meta = svc.spreadsheets().get(spreadsheetId=sheet_id).execute()
    existing = [s['properties']['title'] for s in meta.get('sheets', [])]

    requests = []
    if ARCHIVE_NAME not in existing:
        requests.append({'addSheet': {'properties': {'title': ARCHIVE_NAME}}})
    if 'Note Archiviate' not in existing:
        requests.append({'addSheet': {'properties': {'title': 'Note Archiviate'}}})

    if requests:
        svc.spreadsheets().batchUpdate(
            spreadsheetId=sheet_id,
            body={'requests': requests}
        ).execute()

    # Header Ticket Risolti
    res = svc.spreadsheets().values().get(
        spreadsheetId=sheet_id, range=f"'{ARCHIVE_NAME}'!A1").execute()
    if not res.get('values'):
        svc.spreadsheets().values().update(
            spreadsheetId=sheet_id, range=f"'{ARCHIVE_NAME}'!A1",
            valueInputOption='RAW',
            body={'values': [SHEET_HEADERS + ['DataArchiviazione']]}
        ).execute()

    # Header Note Archiviate
    res2 = svc.spreadsheets().values().get(
        spreadsheetId=sheet_id, range="'Note Archiviate'!A1").execute()
    if not res2.get('values'):
        svc.spreadsheets().values().update(
            spreadsheetId=sheet_id, range="'Note Archiviate'!A1",
            valueInputOption='RAW',
            body={'values': [NOTES_HEADERS]}
        ).execute()


def _get_sheet_id_by_name(svc, spreadsheet_id: str, sheet_name: str) -> int | None:
    """Restituisce lo sheetId numerico di un tab per nome."""
    meta = svc.spreadsheets().get(spreadsheetId=spreadsheet_id).execute()
    for s in meta.get('sheets', []):
        if s['properties']['title'] == sheet_name:
            return s['properties']['sheetId']
    return None


def _delete_row(svc, spreadsheet_id: str, sheet_name: str, row_num: int):
    """Elimina fisicamente una riga (row_num 1-based, inclusa header=1)."""
    try:
        sid = _get_sheet_id_by_name(svc, spreadsheet_id, sheet_name)
        if sid is None:
            print(f"[SH] ❌ _delete_row: sheet '{sheet_name}' non trovato")
            return
        print(f"[SH] _delete_row: sheet='{sheet_name}' sid={sid} row={row_num} (0-based: {row_num-1})")
        svc.spreadsheets().batchUpdate(
            spreadsheetId=spreadsheet_id,
            body={'requests': [{
                'deleteDimension': {
                    'range': {
                        'sheetId': sid,
                        'dimension': 'ROWS',
                        'startIndex': row_num - 1,  # 0-based
                        'endIndex':   row_num,
                    }
                }
            }]}
        ).execute()
        print(f"[SH] ✅ Riga {row_num} eliminata da '{sheet_name}'")
    except Exception as e:
        print(f"[SH] ❌ _delete_row errore riga {row_num} in '{sheet_name}': {e}")


def archive_ticket(svc, sheet_id: str, ticket_id: str) -> bool:
    """
    Sposta ticket + relative note negli archivi.
    Elimina fisicamente le righe dai tab attivi.
    """
    try:
        _ensure_archive_tabs(svc, sheet_id)

        # ── 1. Archivia ticket ──────────────────────────────
        row_num = find_ticket_row(svc, sheet_id, ticket_id)
        if row_num < 0:
            print(f"[SH] Ticket {ticket_id} non trovato per archivio")
            return False

        result = svc.spreadsheets().values().get(
            spreadsheetId=sheet_id,
            range=f'{SHEET_NAME}!A{row_num}:O{row_num}'
        ).execute()
        row_data = result.get('values', [[]])[0] if result.get('values') else []
        if not row_data:
            return False

        # Append in Ticket Risolti con data archiviazione
        row_data_arch = list(row_data) + [datetime.now().isoformat()]
        svc.spreadsheets().values().append(
            spreadsheetId=sheet_id,
            range=f"'{ARCHIVE_NAME}'!A1",
            valueInputOption='RAW',
            insertDataOption='INSERT_ROWS',
            body={'values': [row_data_arch]}
        ).execute()

        # Elimina riga fisicamente dal tab Tickets
        _delete_row(svc, sheet_id, SHEET_NAME, row_num)
        print(f"[SH] ✅ Ticket {ticket_id} archiviato e rimosso da Tickets")

        # ── 2. Archivia note relative ───────────────────────
        try:
            notes_result = svc.spreadsheets().values().get(
                spreadsheetId=sheet_id,
                range=f'{NOTES_NAME}!A2:E'
            ).execute()
            notes_rows = notes_result.get('values', [])

            # Trova righe note da archiviare (in ordine inverso per non sfasare indici)
            note_indices = []
            for i, row in enumerate(notes_rows):
                while len(row) < 5:
                    row.append('')
                if row[0] == ticket_id:
                    note_indices.append((i + 2, row))  # +2: header + base-1

            if note_indices:
                print(f"[SH] Archivio {len(note_indices)} note per {ticket_id}: righe {[r for r,_ in note_indices]}")
                # Append note in Note Archiviate
                svc.spreadsheets().values().append(
                    spreadsheetId=sheet_id,
                    range="'Note Archiviate'!A1",
                    valueInputOption='RAW',
                    insertDataOption='INSERT_ROWS',
                    body={'values': [r for _, r in note_indices]}
                ).execute()
                print(f"[SH] Append note completato, ora elimino righe in ordine inverso")

                # Elimina righe in ordine inverso (dal basso verso l'alto)
                # IMPORTANTE: after ogni delete le righe successive scalano di 1
                sorted_indices = sorted([r for r,_ in note_indices], reverse=True)
                print(f"[SH] Elimino righe: {sorted_indices}")
                for row_idx in sorted_indices:
                    print(f"[SH] Elimino riga {row_idx} da {NOTES_NAME}")
                    _delete_row(svc, sheet_id, NOTES_NAME, row_idx)

                print(f"[SH] ✅ {len(note_indices)} note di {ticket_id} archiviate e rimosse")
            else:
                print(f"[SH] Nessuna nota trovata per ticket {ticket_id}")

        except Exception as e:
            print(f"[SH] Warning archivio note {ticket_id}: {e}")

        return True

    except Exception as e:
        print(f"[SH] ❌ Errore archiviazione {ticket_id}: {e}")
        return False

def _col_letter(idx: int) -> str:
    """Converte indice 0-based in lettera colonna (A, B, ... Z, AA...)."""
    result = ''
    idx += 1
    while idx:
        idx, rem = divmod(idx - 1, 26)
        result = chr(65 + rem) + result
    return result


def extract_ticket_id_from_subject(subject: str) -> str | None:
    """Estrae TKT-XXXXXXX dal subject della mail."""
    match = re.search(r'TKT-[A-Z0-9]+', subject or '')
    return match.group(0) if match else None

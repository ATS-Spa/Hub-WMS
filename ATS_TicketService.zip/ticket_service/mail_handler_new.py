"""
mail_handler.py — aggiornato
"""
import re
import smtplib
import ssl
import time
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from datetime import datetime, timedelta


# ── INVIO ──────────────────────────────────────────────────────────────────

def send_via_outlook(
    to: str,
    subject: str,
    body: str,
    from_address: str,
    in_reply_to: str = '',
    references: str = '',
    reply_to: str = '',
    log_fn=None
) -> str:
    try:
        import win32com.client
        import pythoncom
        pythoncom.CoInitialize()
        outlook = win32com.client.Dispatch('Outlook.Application')
        ns = outlook.GetNamespace('MAPI')

        # ── Trova account per from_address ──────────────────
        account = None
        found_addr = ''
        # Prima passa esatta su SmtpAddress
        for acc in ns.Accounts:
            try:
                smtp = acc.SmtpAddress or ''
                if smtp.lower() == from_address.lower():
                    account = acc
                    found_addr = smtp
                    break
            except Exception:
                continue
        # Fallback: ricerca parziale
        if not account:
            for acc in ns.Accounts:
                try:
                    smtp = acc.SmtpAddress or ''
                    name = acc.DisplayName or ''
                    if from_address.lower() in smtp.lower() or from_address.lower() in name.lower():
                        account = acc
                        found_addr = smtp
                        break
                except Exception:
                    continue

        if account:
            if log_fn: log_fn(f"[MAIL] Account trovato: {found_addr}")
        else:
            if log_fn: log_fn(f"[MAIL] ⚠ Account {from_address} non trovato, uso default")

        mail = outlook.CreateItem(0)
        mail.To = to
        mail.Subject = subject
        mail.Body = body

        if account:
            mail.SendUsingAccount = account

        # ── Thread via MAPI ─────────────────────────────────
        if in_reply_to:
            try:
                PA = mail.PropertyAccessor
                PA.SetProperty('http://schemas.microsoft.com/mapi/proptag/0x1042001E', in_reply_to)
                ref = (references + ' ' + in_reply_to).strip() if references else in_reply_to
                PA.SetProperty('http://schemas.microsoft.com/mapi/proptag/0x1039001E', ref)
                if log_fn: log_fn(f"[MAIL] Thread: {in_reply_to[:50]}")
            except Exception as e:
                if log_fn: log_fn(f"[MAIL] Warning thread: {e}")

        # ── Reply-To ────────────────────────────────────────
        if reply_to:
            try:
                r = mail.ReplyRecipients.Add(reply_to)
                r.Type = 1
                r.Resolve()
            except Exception:
                pass

        mail.Send()
        time.sleep(1.5)
        msg_id = _get_last_sent_message_id(ns, subject, from_address, log_fn)
        if log_fn: log_fn(f"[MAIL] ✉ Inviata via Outlook → {to} | {subject[:50]}")
        return msg_id or ''

    except ImportError:
        raise RuntimeError("win32com non disponibile.")
    except Exception as e:
        raise RuntimeError(f"Errore Outlook: {e}")
    finally:
        try:
            import pythoncom as _pc
            _pc.CoUninitialize()
        except Exception:
            pass


def _get_last_sent_message_id(ns, subject: str, from_address: str, log_fn=None) -> str:
    try:
        PR_MSGID = 'http://schemas.microsoft.com/mapi/proptag/0x1035001E'
        for store in ns.Stores:
            try:
                sent = store.GetDefaultFolder(5)
                items = sent.Items
                items.Sort('[SentOn]', True)
                for i, item in enumerate(items):
                    if i > 15:
                        break
                    try:
                        if subject[:30] in (item.Subject or ''):
                            msg_id = item.PropertyAccessor.GetProperty(PR_MSGID)
                            if msg_id:
                                return msg_id
                    except Exception:
                        continue
            except Exception:
                continue
    except Exception as e:
        if log_fn: log_fn(f"[MAIL] Warning MessageID: {e}")
    return ''


def send_via_smtp(
    to: str,
    subject: str,
    body: str,
    smtp_host: str,
    smtp_port: int,
    smtp_user: str,
    smtp_password: str,
    smtp_from: str,
    use_tls: bool = True,
    in_reply_to: str = '',
    references: str = '',
    log_fn=None
) -> str:
    msg = MIMEMultipart('alternative')
    msg['Subject'] = subject
    msg['From']    = smtp_from
    msg['To']      = to
    if in_reply_to:
        msg['In-Reply-To'] = in_reply_to
        msg['References']  = (references + ' ' + in_reply_to).strip() if references else in_reply_to
    msg.attach(MIMEText(body, 'plain', 'utf-8'))
    ctx = ssl.create_default_context()
    if use_tls:
        with smtplib.SMTP(smtp_host, smtp_port) as server:
            server.ehlo(); server.starttls(context=ctx); server.login(smtp_user, smtp_password)
            server.sendmail(smtp_from, [to], msg.as_string())
    else:
        with smtplib.SMTP_SSL(smtp_host, smtp_port, context=ctx) as server:
            server.login(smtp_user, smtp_password)
            server.sendmail(smtp_from, [to], msg.as_string())
    if log_fn: log_fn(f"[MAIL] ✉ Inviata via SMTP → {to} | {subject[:50]}")
    return ''


# ── LETTURA INBOX ──────────────────────────────────────────────────────────

def read_inbox_replies(
    from_address: str,
    since_hours: int = 24,
    log_fn=None
) -> list:
    results = []
    try:
        import win32com.client
        import pythoncom
        from pywintypes import com_error
        pythoncom.CoInitialize()

        outlook = win32com.client.Dispatch('Outlook.Application')
        ns = outlook.GetNamespace('MAPI')

        # Trova store corretto per from_address
        target_store = None
        for store in ns.Stores:
            try:
                for acc in ns.Accounts:
                    try:
                        if (acc.DeliveryStore and
                            acc.DeliveryStore.StoreID == store.StoreID and
                            acc.SmtpAddress.lower() == from_address.lower()):
                            target_store = store
                            break
                    except Exception:
                        continue
                if target_store:
                    break
            except Exception:
                continue

        inbox = target_store.GetDefaultFolder(6) if target_store else ns.GetDefaultFolder(6)

        since = datetime.now() - timedelta(hours=since_hours)
        since_str = since.strftime('%m/%d/%Y %H:%M %p')
        try:
            items = inbox.Items.Restrict(f"[ReceivedTime] >= '{since_str}'")
        except Exception:
            items = inbox.Items

        for item in items:
            try:
                subject = getattr(item, 'Subject', '') or ''
                if 'TKT-' not in subject.upper():
                    continue

                ticket_id = _extract_ticket_id(subject)
                if not ticket_id:
                    continue

                sender = getattr(item, 'SenderEmailAddress', '') or ''

                # Esclude mail del servizio stesso
                if sender.lower() == from_address.lower():
                    continue

                # Solo mail non lette
                if not getattr(item, 'UnRead', False):
                    continue

                # Solo risposte (Re: / Rif:)
                subj_lower = subject.lower()
                if not any(subj_lower.startswith(p) for p in ['re:', 'rif:', 'r:', 'fw:', 'fwd:']):
                    continue

                body = getattr(item, 'Body', '') or ''
                clean_body = _clean_reply_body(body)
                if not clean_body.strip():
                    continue

                received = getattr(item, 'ReceivedTime', None)
                results.append({
                    'ticket_id':   ticket_id,
                    'subject':     subject,
                    'body':        clean_body,
                    'sender':      sender,
                    'received_at': str(received) if received else '',
                    'entry_id':    getattr(item, 'EntryID', ''),
                })

                # Segna come letta
                try:
                    item.UnRead = False
                    item.Save()
                except Exception:
                    pass

            except Exception as e:
                if log_fn: log_fn(f"[MAIL] Warning item inbox: {e}")
                continue

        if log_fn and results:
            log_fn(f"[MAIL] 📬 {len(results)} risposta/e trovata/e")

    except ImportError:
        if log_fn: log_fn("[MAIL] win32com non disponibile")
    except Exception as e:
        if log_fn: log_fn(f"[MAIL] Errore lettura inbox: {e}")
    finally:
        try:
            import pythoncom as _pc
            _pc.CoUninitialize()
        except Exception:
            pass

    return results


def _get_store_email(ns, store) -> str:
    try:
        for acc in ns.Accounts:
            if acc.DeliveryStore and acc.DeliveryStore.StoreID == store.StoreID:
                return acc.SmtpAddress
    except Exception:
        pass
    return ''


def _extract_ticket_id(subject: str) -> str:
    match = re.search(r'TKT-[A-Z0-9]+', subject.upper())
    return match.group(0) if match else ''


def _clean_reply_body(body: str) -> str:
    lines = body.split('\n')
    clean = []
    for line in lines:
        s = line.strip()
        if any(s.startswith(p) for p in ['> ','-----','___','Da:','From:','Inviato:','Sent:','A:','To:','Oggetto:','Subject:','Il giorno','On ']):
            break
        if s.startswith('---') and len(s) > 10:
            break
        clean.append(line)
    return '\n'.join(clean).strip()


# ── TEMPLATE MAIL ──────────────────────────────────────────────────────────

def build_ticket_body(ticket: dict, tipo: str = 'nuovo', note_testo: str = '',
                      updater: str = '', for_user: bool = False) -> tuple:
    tid   = ticket.get('ID', '')
    title = ticket.get('Titolo', '')
    proj  = ticket.get('Progetto', '')
    prio  = ticket.get('Priorita', '')
    stato = ticket.get('Stato', '')
    autore       = ticket.get('Autore', '')
    autore_email = ticket.get('AutoreEmail', '')
    assegnato    = ticket.get('Assegnato', '')
    data_ap      = ticket.get('DataApertura', '')
    desc         = ticket.get('Descrizione', '')
    sep = '\u2500' * 50

    if tipo == 'nuovo':
        subject = f'[{tid}] Nuovo ticket: {title}'
        if for_user:
            body = (f'Ciao {autore},\n\nla tua richiesta \u00e8 stata registrata correttamente.\n\n'
                    f'{sep}\nRIEPILOGO TICKET\n\n'
                    f'Numero:    {tid}\nTitolo:    {title}\nProgetto:  {proj}\n'
                    f'Tipo:      {ticket.get("Tipo","")}\nPriorit\u00e0:  {prio}\nData:      {_fmt_date(data_ap)}\n')
            if desc: body += f'\nMotivazione:\n{desc}\n'
            body += f'\n{sep}\nRiceverai aggiornamenti via email.\nPer aggiornamenti rispondi citando il numero {tid}.\n\nWMS Hub \u00b7 Ticket Manager ATS'
        else:
            body = (f'NUOVO TICKET APERTO\n{sep}\n\n'
                    f'ID:        {tid}\nTitolo:    {title}\nProgetto:  {proj}\n'
                    f'Tipo:      {ticket.get("Tipo","")}\nPriorit\u00e0:  {prio}\nStato:     {stato}\n'
                    f'Aperto da: {autore} <{autore_email}>\nData:      {_fmt_date(data_ap)}\n')
            if desc: body += f'\nDescrizione:\n{desc}\n'
            body += f'\n{sep}\nWMS Hub \u00b7 Ticket Manager ATS'

    elif tipo == 'assegnato':
        subject = f'[{tid}] Ticket preso in carico: {title}'
        if for_user:
            body = (f'Ciao {autore},\n\nil tuo ticket \u00e8 stato preso in carico da {assegnato}.\n\n'
                    f'{sep}\nID: {tid}\nTitolo: {title}\nAssegnato a: {assegnato}\nStato: {stato}\n\n'
                    f'{sep}\nWMS Hub \u00b7 Ticket Manager ATS')
        else:
            body = (f'TICKET ASSEGNATO\n{sep}\n\nID: {tid}\nTitolo: {title}\n'
                    f'Progetto: {proj}\nAssegnato a: {assegnato}\nStato: {stato}\n\n'
                    f'{sep}\nWMS Hub \u00b7 Ticket Manager ATS')

    elif tipo == 'stato':
        subject = f'[{tid}] Aggiornamento: {stato} \u2014 {title}'
        if for_user:
            body = (f'Ciao {autore},\n\nil tuo ticket ha ricevuto un aggiornamento.\n\n'
                    f'{sep}\nID: {tid}\nTitolo: {title}\nNuovo stato: {stato}\nAggiornato da: {updater}\n\n'
                    f'{sep}\nWMS Hub \u00b7 Ticket Manager ATS')
        else:
            body = (f'AGGIORNAMENTO STATO\n{sep}\n\nID: {tid}\nTitolo: {title}\n'
                    f'Progetto: {proj}\nNuovo stato: {stato}\nAggiornato da: {updater}\n\n'
                    f'{sep}\nWMS Hub \u00b7 Ticket Manager ATS')

    elif tipo == 'nota':
        subject = f'[{tid}] Nuova nota: {title}'
        if for_user:
            body = (f'Ciao {autore},\n\n\u00e8 stata aggiunta una nota al tuo ticket.\n\n'
                    f'{sep}\nID: {tid}\nTitolo: {title}\nAutore: {updater}\n\nNota:\n{note_testo}\n\n'
                    f'{sep}\nWMS Hub \u00b7 Ticket Manager ATS')
        else:
            body = (f'NUOVA NOTA\n{sep}\n\nID: {tid}\nTitolo: {title}\n'
                    f'Autore: {updater}\n\nNota:\n{note_testo}\n\n'
                    f'{sep}\nWMS Hub \u00b7 Ticket Manager ATS')
    else:
        subject = f'[{tid}] {title}'
        body    = f'Ticket: {tid}\n{sep}\nWMS Hub \u00b7 Ticket Manager ATS'

    return subject, body


def _fmt_date(iso: str) -> str:
    try:
        dt = datetime.fromisoformat(iso)
        return dt.strftime('%d/%m/%Y %H:%M')
    except Exception:
        return iso

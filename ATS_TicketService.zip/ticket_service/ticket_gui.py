"""
ticket_gui.py
Interfaccia grafica configuratore + monitor per il servizio ticket ATS.
Compilabile con PyInstaller → ticket_gui.exe
"""
import sys
import os
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, scrolledtext
from pathlib import Path
from datetime import datetime

import config_manager as cfg
from ticket_service import TicketService, setup_logging

# System tray (opzionale)
try:
    import pystray
    from PIL import Image, ImageDraw
    HAS_TRAY = True
except ImportError:
    HAS_TRAY = False

# ── Palette colori ─────────────────────────────────────────────────────────
BG      = '#0d1117'
SURFACE = '#161b22'
CARD    = '#1c2333'
BORDER  = '#30363d'
ORANGE  = '#f97316'
TEAL    = '#14b8a6'
GREEN   = '#10b981'
RED     = '#ef4444'
AMBER   = '#f59e0b'
BLUE    = '#3b82f6'
TEXT    = '#e6edf3'
MUTED   = '#8b949e'
WHITE   = '#ffffff'

FONT_MAIN  = ('Segoe UI', 10)
FONT_BOLD  = ('Segoe UI', 10, 'bold')
FONT_TITLE = ('Segoe UI', 13, 'bold')
FONT_MONO  = ('Consolas', 9)
FONT_SMALL = ('Segoe UI', 9)


class TicketGUI(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title('ATS Ticket Service — Configuratore')
        self.geometry('920x680')
        self.minsize(800, 580)
        self.configure(bg=BG)
        self.resizable(True, True)

        # Icona (se disponibile)
        try:
            self.iconbitmap(default='ticket.ico')
        except Exception:
            pass

        self._service: TicketService | None = None
        self._svc_thread: threading.Thread | None = None
        self._log_lines = []

        setup_logging(log_callback=self._append_log)
        self._build_ui()
        self._load_fields()
        self.protocol('WM_DELETE_WINDOW', self._on_close)
        # tray avviato dall'entry point main, non qui

    # ── UI ──────────────────────────────────────────────────────────────────

    def _build_ui(self):
        # Header
        hdr = tk.Frame(self, bg=SURFACE, height=52)
        hdr.pack(fill='x')
        hdr.pack_propagate(False)
        tk.Label(hdr, text='🎫  ATS Ticket Service', font=('Segoe UI', 14, 'bold'),
                 bg=SURFACE, fg=ORANGE).pack(side='left', padx=16, pady=12)
        self._status_lbl = tk.Label(hdr, text='● Fermo', font=FONT_BOLD,
                                    bg=SURFACE, fg=RED)
        self._status_lbl.pack(side='right', padx=16)

        # Notebook tabs
        style = ttk.Style(self)
        style.theme_use('clam')
        style.configure('TNotebook',        background=BG,      borderwidth=0)
        style.configure('TNotebook.Tab',    background=SURFACE, foreground=MUTED,
                        padding=[14, 8],    font=FONT_BOLD)
        style.map('TNotebook.Tab',
                  background=[('selected', CARD)],
                  foreground=[('selected', ORANGE)])
        style.configure('TFrame', background=BG)
        style.configure('TLabelframe',      background=CARD,    foreground=TEXT, bordercolor=BORDER)
        style.configure('TLabelframe.Label',background=CARD,    foreground=ORANGE, font=FONT_BOLD)

        nb = ttk.Notebook(self)
        nb.pack(fill='both', expand=True, padx=10, pady=(8, 0))

        self._tab_google   = ttk.Frame(nb)
        self._tab_mail     = ttk.Frame(nb)
        self._tab_smtp     = ttk.Frame(nb)
        self._tab_service  = ttk.Frame(nb)
        self._tab_monitor  = ttk.Frame(nb)

        nb.add(self._tab_google,  text='  Google API  ')
        nb.add(self._tab_mail,    text='  Outlook / Mail  ')
        nb.add(self._tab_smtp,    text='  SMTP Exchange  ')
        nb.add(self._tab_service, text='  Servizio  ')
        nb.add(self._tab_monitor, text='  Monitor & Log  ')

        self._build_google_tab()
        self._build_mail_tab()
        self._build_smtp_tab()
        self._build_service_tab()
        self._build_monitor_tab()

        # Footer
        footer = tk.Frame(self, bg=SURFACE, height=44)
        footer.pack(fill='x', side='bottom')
        footer.pack_propagate(False)
        self._btn_save = self._btn(footer, '💾  Salva Config', self._save_config, TEAL)
        self._btn_save.pack(side='right', padx=10, pady=8)
        self._btn_start = self._btn(footer, '▶  Avvia Servizio', self._start_service, GREEN)
        self._btn_start.pack(side='right', padx=4, pady=8)
        self._btn_stop = self._btn(footer, '⏹  Ferma', self._stop_service, RED)
        self._btn_stop.pack(side='right', padx=4, pady=8)
        self._btn_once = self._btn(footer, '🔄  Esegui Ora', self._run_once, AMBER)
        self._btn_once.pack(side='right', padx=4, pady=8)
        self._btn_stop.config(state='disabled')

    def _build_google_tab(self):
        f = self._tab_google
        self._lf(f, 'Service Account Google').pack(fill='x', padx=14, pady=(14, 6))
        grp = self._lf(f, 'Service Account Google')
        grp.pack(fill='x', padx=14, pady=(14, 6))

        self._row(grp, 'File JSON Service Account *',
                  hint='Scaricato da Google Cloud Console → IAM → Service Accounts → Keys')
        self._sa_var = tk.StringVar()
        row = tk.Frame(grp, bg=CARD)
        row.pack(fill='x', padx=10, pady=(0, 8))
        tk.Entry(row, textvariable=self._sa_var, bg=SURFACE, fg=TEXT, insertbackground=TEXT,
                 relief='flat', font=FONT_MAIN, bd=0).pack(side='left', fill='x', expand=True,
                 ipady=6, padx=(8, 0))
        self._btn(row, '📂 Sfoglia', lambda: self._browse_file(self._sa_var, 'json'), MUTED,
                  font=FONT_SMALL).pack(side='right', padx=6, pady=4)

        self._row(grp, 'Sheet ID (lascia vuoto = auto-rilevato da Drive)')
        self._sheet_id_var = tk.StringVar()
        self._entry(grp, self._sheet_id_var)

        self._row(grp, 'ID file config_tickets.json su Drive',
                  hint='Apri il file su Drive → URL → /d/{ID}/')
        self._config_drive_id_var = tk.StringVar()
        self._entry(grp, self._config_drive_id_var)

        self._row(grp, 'ID Cartella Dati Drive (Gestione Ticketing)')
        self._folder_data_var = tk.StringVar()
        self._entry(grp, self._folder_data_var)

        # Test connessione
        btn_row = tk.Frame(grp, bg=CARD)
        btn_row.pack(fill='x', padx=10, pady=(4, 10))
        self._btn(btn_row, '🔌 Testa Connessione Google', self._test_google, BLUE).pack(side='left')
        self._google_test_lbl = tk.Label(btn_row, text='', font=FONT_SMALL, bg=CARD, fg=MUTED)
        self._google_test_lbl.pack(side='left', padx=10)

    def _build_mail_tab(self):
        f = self._tab_mail
        grp = self._lf(f, 'Account Outlook (su questo PC)')
        grp.pack(fill='x', padx=14, pady=(14, 6))

        self._row(grp, 'Indirizzo email account Outlook da usare *',
                  hint='Deve essere configurato in Outlook su questo PC come account secondario')
        self._outlook_addr_var = tk.StringVar()
        self._entry(grp, self._outlook_addr_var, placeholder='itlogisticsata@atsgruppo.eu')

        self._row(grp, 'Email destinatario notifiche *',
                  hint='A chi arrivano le notifiche dei nuovi ticket')
        self._mail_notifiche_var = tk.StringVar()
        self._entry(grp, self._mail_notifiche_var, placeholder='itlogisticsata@atsgruppo.eu')

        # Test Outlook
        btn_row = tk.Frame(grp, bg=CARD)
        btn_row.pack(fill='x', padx=10, pady=(4, 10))
        self._btn(btn_row, '📧 Invia Mail di Test', self._test_outlook, BLUE).pack(side='left')
        self._outlook_test_lbl = tk.Label(btn_row, text='', font=FONT_SMALL, bg=CARD, fg=MUTED)
        self._outlook_test_lbl.pack(side='left', padx=10)

        # Info box
        info = tk.Frame(f, bg='#1a2a1a', bd=1, relief='solid')
        info.pack(fill='x', padx=14, pady=6)
        tk.Label(info, text=(
            'ℹ️  Outlook deve essere installato e l\'account secondario già configurato.\n'
            '   Il servizio usa direttamente Outlook per inviare e leggere le mail.\n'
            '   Non serve configurare SMTP/IMAP separatamente.'
        ), font=FONT_SMALL, bg='#1a2a1a', fg='#6ee77a', justify='left',
           wraplength=700).pack(padx=12, pady=8, anchor='w')

    def _build_smtp_tab(self):
        f = self._tab_smtp
        # Toggle
        toggle_frm = tk.Frame(f, bg=BG)
        toggle_frm.pack(fill='x', padx=14, pady=(14, 4))
        self._use_smtp_var = tk.BooleanVar()
        tk.Checkbutton(toggle_frm, text='Usa SMTP Exchange (alternativa a Outlook)',
                       variable=self._use_smtp_var, command=self._toggle_smtp,
                       bg=BG, fg=TEXT, selectcolor=CARD, activebackground=BG,
                       font=FONT_BOLD, cursor='hand2').pack(side='left')

        self._smtp_frame = self._lf(f, 'Parametri SMTP Exchange')
        self._smtp_frame.pack(fill='x', padx=14, pady=6)

        self._row(self._smtp_frame, 'Host SMTP')
        self._smtp_host_var = tk.StringVar()
        self._entry(self._smtp_frame, self._smtp_host_var, placeholder='mail.atsgruppo.eu')

        row2 = tk.Frame(self._smtp_frame, bg=CARD)
        row2.pack(fill='x', padx=10, pady=(0, 6))
        tk.Label(row2, text='Porta', font=FONT_SMALL, bg=CARD, fg=MUTED, width=8, anchor='w').pack(side='left')
        self._smtp_port_var = tk.StringVar(value='587')
        tk.Entry(row2, textvariable=self._smtp_port_var, bg=SURFACE, fg=TEXT,
                 insertbackground=TEXT, relief='flat', font=FONT_MAIN, width=8).pack(side='left', ipady=5, padx=4)
        self._smtp_tls_var = tk.BooleanVar(value=True)
        tk.Checkbutton(row2, text='STARTTLS', variable=self._smtp_tls_var,
                       bg=CARD, fg=TEXT, selectcolor=SURFACE, activebackground=CARD,
                       font=FONT_SMALL).pack(side='left', padx=12)

        self._row(self._smtp_frame, 'Utente SMTP')
        self._smtp_user_var = tk.StringVar()
        self._entry(self._smtp_frame, self._smtp_user_var)

        self._row(self._smtp_frame, 'Password SMTP')
        self._smtp_pass_var = tk.StringVar()
        self._entry(self._smtp_frame, self._smtp_pass_var, show='●')

        self._row(self._smtp_frame, 'From (indirizzo mittente)')
        self._smtp_from_var = tk.StringVar()
        self._entry(self._smtp_frame, self._smtp_from_var)

        btn_row = tk.Frame(self._smtp_frame, bg=CARD)
        btn_row.pack(fill='x', padx=10, pady=(4, 10))
        self._btn(btn_row, '🔌 Testa SMTP', self._test_smtp, BLUE).pack(side='left')
        self._smtp_test_lbl = tk.Label(btn_row, text='', font=FONT_SMALL, bg=CARD, fg=MUTED)
        self._smtp_test_lbl.pack(side='left', padx=10)

    def _build_service_tab(self):
        f = self._tab_service
        grp = self._lf(f, 'Parametri Servizio')
        grp.pack(fill='x', padx=14, pady=(14, 6))

        self._row(grp, 'Intervallo polling (secondi)',
                  hint='Ogni quanti secondi controlla nuovi ticket e risposte email. Min 60.')
        self._interval_var = tk.StringVar(value='120')
        self._entry(grp, self._interval_var, placeholder='120')

        self._row(grp, 'Max righe log')
        self._log_max_var = tk.StringVar(value='500')
        self._entry(grp, self._log_max_var, placeholder='500')

        # Autostart
        grp2 = self._lf(f, 'Avvio Automatico Windows')
        grp2.pack(fill='x', padx=14, pady=6)
        self._autostart_var = tk.BooleanVar()
        tk.Checkbutton(grp2, text='Avvia servizio automaticamente con Windows (Task Scheduler)',
                       variable=self._autostart_var,
                       bg=CARD, fg=TEXT, selectcolor=SURFACE, activebackground=CARD,
                       font=FONT_MAIN, cursor='hand2').pack(padx=10, pady=6, anchor='w')
        btn_row2 = tk.Frame(grp2, bg=CARD)
        btn_row2.pack(fill='x', padx=10, pady=(0, 10))
        self._btn(btn_row2, '⚙ Registra in Task Scheduler', self._register_task, AMBER).pack(side='left')
        self._btn(btn_row2, '🗑 Rimuovi da Task Scheduler', self._unregister_task, RED).pack(side='left', padx=6)

        # Info path
        grp3 = self._lf(f, 'Percorsi')
        grp3.pack(fill='x', padx=14, pady=6)
        from pathlib import Path
        import os
        cfg_path = Path(os.getenv('APPDATA', '.')) / 'ATS_TicketService'
        tk.Label(grp3, text=f'Config: {cfg_path}', font=FONT_MONO,
                 bg=CARD, fg=MUTED).pack(padx=10, pady=(6, 2), anchor='w')
        tk.Label(grp3, text=f'Log:    {cfg_path / "logs"}', font=FONT_MONO,
                 bg=CARD, fg=MUTED).pack(padx=10, pady=(0, 6), anchor='w')

    def _build_monitor_tab(self):
        f = self._tab_monitor

        # Stats row
        stats = tk.Frame(f, bg=BG)
        stats.pack(fill='x', padx=14, pady=(10, 4))
        self._stat_status = self._stat_box(stats, 'Stato', 'Fermo', RED)
        self._stat_last   = self._stat_box(stats, 'Ultimo ciclo', '—', MUTED)
        self._stat_sent   = self._stat_box(stats, 'Mail inviate', '0', TEAL)
        self._stat_inbox  = self._stat_box(stats, 'Risposte lette', '0', GREEN)

        # Log
        log_frm = tk.Frame(f, bg=BG)
        log_frm.pack(fill='both', expand=True, padx=14, pady=4)
        tk.Label(log_frm, text='Log in tempo reale', font=FONT_BOLD,
                 bg=BG, fg=MUTED).pack(anchor='w', pady=(0, 4))
        self._log_txt = scrolledtext.ScrolledText(
            log_frm, bg=CARD, fg='#22c55e', insertbackground=TEXT,
            font=FONT_MONO, relief='flat', bd=0, wrap='word',
            state='disabled'
        )
        self._log_txt.pack(fill='both', expand=True)
        self._log_txt.configure(selectbackground=BORDER)

        # Colori log
        self._log_txt.tag_config('err',  foreground=RED)
        self._log_txt.tag_config('warn', foreground=AMBER)
        self._log_txt.tag_config('ok',   foreground=GREEN)
        self._log_txt.tag_config('info', foreground='#22c55e')

        btn_row = tk.Frame(f, bg=BG)
        btn_row.pack(fill='x', padx=14, pady=(4, 8))
        self._btn(btn_row, '🗑 Pulisci log', self._clear_log, MUTED, font=FONT_SMALL).pack(side='left')
        self._btn(btn_row, '📂 Apri cartella log', self._open_log_dir, MUTED, font=FONT_SMALL).pack(side='left', padx=6)

    def _stat_box(self, parent, label, value, color):
        frm = tk.Frame(parent, bg=CARD, bd=1, relief='solid')
        frm.pack(side='left', padx=(0, 8), pady=2, ipadx=12, ipady=6)
        tk.Label(frm, text=label, font=FONT_SMALL, bg=CARD, fg=MUTED).pack()
        val_lbl = tk.Label(frm, text=value, font=FONT_BOLD, bg=CARD, fg=color)
        val_lbl.pack()
        return val_lbl

    # ── Helpers UI ──────────────────────────────────────────────────────────

    def _lf(self, parent, title=''):
        frm = tk.LabelFrame(parent, text=f'  {title}  ' if title else '',
                             bg=CARD, fg=ORANGE, font=FONT_BOLD,
                             relief='flat', bd=1, labelanchor='nw')
        return frm

    def _row(self, parent, label, hint=''):
        tk.Label(parent, text=label, font=FONT_SMALL, bg=CARD, fg=MUTED,
                 anchor='w').pack(fill='x', padx=10, pady=(8, 0))
        if hint:
            tk.Label(parent, text=hint, font=('Segoe UI', 8), bg=CARD, fg='#484f58',
                     anchor='w', wraplength=600).pack(fill='x', padx=10)

    def _entry(self, parent, var, placeholder='', show=''):
        e = tk.Entry(parent, textvariable=var, bg=SURFACE, fg=TEXT,
                     insertbackground=TEXT, relief='flat', font=FONT_MAIN,
                     bd=0, show=show)
        e.pack(fill='x', padx=10, pady=(2, 6), ipady=6)
        if placeholder and not var.get():
            e.insert(0, placeholder)
            e.config(fg=MUTED)
            def on_focus_in(ev):
                if e.get() == placeholder:
                    e.delete(0, 'end')
                    e.config(fg=TEXT)
            def on_focus_out(ev):
                if not e.get():
                    e.insert(0, placeholder)
                    e.config(fg=MUTED)
                    var.set('')
            e.bind('<FocusIn>', on_focus_in)
            e.bind('<FocusOut>', on_focus_out)
        return e

    def _btn(self, parent, text, cmd, color=ORANGE, font=None):
        b = tk.Button(parent, text=text, command=cmd,
                      bg=color, fg=WHITE, relief='flat',
                      font=font or FONT_BOLD, cursor='hand2',
                      padx=12, pady=5, activebackground=color)
        return b

    def _browse_file(self, var: tk.StringVar, ext: str):
        path = filedialog.askopenfilename(filetypes=[(f'{ext.upper()} files', f'*.{ext}')])
        if path:
            var.set(path)

    def _toggle_smtp(self):
        state = 'normal' if self._use_smtp_var.get() else 'disabled'
        for child in self._smtp_frame.winfo_children():
            try:
                child.configure(state=state)
            except Exception:
                pass

    # ── Config load/save ────────────────────────────────────────────────────

    def _load_fields(self):
        c = cfg.load_config()
        self._sa_var.set(c.get('service_account_json', ''))
        self._sheet_id_var.set(c.get('sheet_id', ''))
        self._config_drive_id_var.set(c.get('config_drive_file_id', ''))
        self._folder_data_var.set(c.get('drive_folder_data', '11ocsebXn-EPfhiIxTf3J6kZ3fH3xQYmf'))
        self._outlook_addr_var.set(c.get('outlook_mail_address', ''))
        self._mail_notifiche_var.set(c.get('mail_notifiche', 'itlogisticsata@atsgruppo.eu'))
        self._use_smtp_var.set(c.get('use_smtp', False))
        self._smtp_host_var.set(c.get('smtp_host', ''))
        self._smtp_port_var.set(str(c.get('smtp_port', 587)))
        self._smtp_user_var.set(c.get('smtp_user', ''))
        self._smtp_pass_var.set(c.get('smtp_password', ''))
        self._smtp_from_var.set(c.get('smtp_from', ''))
        self._smtp_tls_var.set(c.get('smtp_use_tls', True))
        self._interval_var.set(str(c.get('polling_interval_sec', 120)))
        self._log_max_var.set(str(c.get('log_max_lines', 500)))
        self._autostart_var.set(c.get('autostart', False))

    def _save_config(self):
        c = cfg.load_config()
        c['service_account_json'] = self._sa_var.get().strip()
        c['sheet_id']             = self._sheet_id_var.get().strip()
        c['config_drive_file_id'] = self._config_drive_id_var.get().strip()
        c['drive_folder_data']    = self._folder_data_var.get().strip()
        c['outlook_mail_address'] = self._outlook_addr_var.get().strip()
        c['mail_notifiche']       = self._mail_notifiche_var.get().strip()
        c['use_smtp']             = self._use_smtp_var.get()
        c['smtp_host']            = self._smtp_host_var.get().strip()
        c['smtp_port']            = int(self._smtp_port_var.get() or 587)
        c['smtp_user']            = self._smtp_user_var.get().strip()
        c['smtp_password']        = self._smtp_pass_var.get().strip()
        c['smtp_from']            = self._smtp_from_var.get().strip()
        c['smtp_use_tls']         = self._smtp_tls_var.get()
        c['polling_interval_sec'] = int(self._interval_var.get() or 120)
        c['log_max_lines']        = int(self._log_max_var.get() or 500)
        c['autostart']            = self._autostart_var.get()
        cfg.save_config(c)
        messagebox.showinfo('Salvato', 'Configurazione salvata correttamente.')
        self._append_log('[GUI] ✅ Configurazione salvata')

    # ── Test connessioni ────────────────────────────────────────────────────

    def _test_google(self):
        self._google_test_lbl.config(text='Testing...', fg=AMBER)
        def run():
            try:
                import sheets_handler as sh
                sa = self._sa_var.get().strip()
                if not sa:
                    raise ValueError("Seleziona prima il file JSON")
                svc = sh.get_service(sa)
                # Prova a fare una chiamata reale
                sheet_id = self._sheet_id_var.get().strip()
                if sheet_id:
                    svc.spreadsheets().get(spreadsheetId=sheet_id).execute()
                    self.after(0, lambda: self._google_test_lbl.config(text='✅ Sheet raggiungibile', fg=GREEN))
                else:
                    self.after(0, lambda: self._google_test_lbl.config(text='✅ Service Account OK (no Sheet ID)', fg=AMBER))
            except Exception as e:
                err = str(e)[:60]
                self.after(0, lambda: self._google_test_lbl.config(text=f'❌ {err}', fg=RED))
        threading.Thread(target=run, daemon=True).start()

    def _test_outlook(self):
        self._outlook_test_lbl.config(text='Testing...', fg=AMBER)
        def run():
            try:
                import win32com.client
                outlook = win32com.client.Dispatch('Outlook.Application')
                ns = outlook.GetNamespace('MAPI')
                addr = self._outlook_addr_var.get().strip()
                found = any(acc.SmtpAddress.lower() == addr.lower() for acc in ns.Accounts)
                if found:
                    self.after(0, lambda: self._outlook_test_lbl.config(text=f'✅ Account trovato', fg=GREEN))
                else:
                    accounts = [acc.SmtpAddress for acc in ns.Accounts]
                    self.after(0, lambda: self._outlook_test_lbl.config(
                        text=f'⚠️ Non trovato. Disponibili: {", ".join(accounts)}', fg=AMBER))
            except Exception as e:
                err = str(e)[:60]
                self.after(0, lambda: self._outlook_test_lbl.config(text=f'❌ {err}', fg=RED))
        threading.Thread(target=run, daemon=True).start()

    def _test_smtp(self):
        self._smtp_test_lbl.config(text='Testing...', fg=AMBER)
        def run():
            try:
                import smtplib, ssl
                host = self._smtp_host_var.get().strip()
                port = int(self._smtp_port_var.get() or 587)
                user = self._smtp_user_var.get().strip()
                pwd  = self._smtp_pass_var.get().strip()
                tls  = self._smtp_tls_var.get()
                ctx  = ssl.create_default_context()
                if tls:
                    with smtplib.SMTP(host, port, timeout=8) as s:
                        s.ehlo(); s.starttls(context=ctx); s.login(user, pwd)
                else:
                    with smtplib.SMTP_SSL(host, port, context=ctx, timeout=8) as s:
                        s.login(user, pwd)
                self.after(0, lambda: self._smtp_test_lbl.config(text='✅ Connessione SMTP OK', fg=GREEN))
            except Exception as e:
                err = str(e)[:60]
                self.after(0, lambda: self._smtp_test_lbl.config(text=f'❌ {err}', fg=RED))
        threading.Thread(target=run, daemon=True).start()

    # ── Servizio ────────────────────────────────────────────────────────────

    def _start_service(self):
        if self._service:
            return
        self._save_config()
        self._service = TicketService(log_callback=self._append_log)
        self._svc_thread = self._service.start()
        self._set_running(True)
        self._append_log('[GUI] ▶ Servizio avviato')

    def _stop_service(self):
        if self._service:
            self._service.stop()
            self._service = None
        self._set_running(False)
        self._append_log('[GUI] ⏹ Servizio fermato')

    def _run_once(self):
        """Esegue un singolo ciclo senza avviare il loop."""
        def run():
            tmp = TicketService(log_callback=self._append_log)
            try:
                tmp.run_once()
            except Exception as e:
                self._append_log(f'[GUI] ❌ Errore ciclo singolo: {e}')
        threading.Thread(target=run, daemon=True).start()

    def _set_running(self, running: bool):
        color = GREEN if running else RED
        text  = '● In esecuzione' if running else '● Fermo'
        self._status_lbl.config(text=text, fg=color)
        self._stat_status.config(text='In esecuzione' if running else 'Fermo', fg=color)
        self._btn_start.config(state='disabled' if running else 'normal')
        self._btn_stop.config(state='normal' if running else 'disabled')
        self._update_tray(running)

    # ── Log ─────────────────────────────────────────────────────────────────

    def _append_log(self, msg: str):
        def _do():
            ts  = datetime.now().strftime('%H:%M:%S')
            line = f'[{ts}] {msg}\n'
            tag = 'info'
            if '❌' in msg or 'Errore' in msg or 'errore' in msg:
                tag = 'err'
            elif '⚠' in msg or 'Warning' in msg:
                tag = 'warn'
            elif '✅' in msg or '▶' in msg or '✉' in msg or '📬' in msg:
                tag = 'ok'

            self._log_txt.configure(state='normal')
            self._log_txt.insert('end', line, tag)
            # Trim
            max_lines = int(self._log_max_var.get() or 500)
            lines = int(self._log_txt.index('end-1c').split('.')[0])
            if lines > max_lines:
                self._log_txt.delete('1.0', f'{lines - max_lines}.0')
            self._log_txt.see('end')
            self._log_txt.configure(state='disabled')
            # Aggiorna stat ultimo ciclo
            if 'Ciclo controllo' in msg:
                self._stat_last.config(text=ts)
        self.after(0, _do)

    def _clear_log(self):
        self._log_txt.configure(state='normal')
        self._log_txt.delete('1.0', 'end')
        self._log_txt.configure(state='disabled')

    def _open_log_dir(self):
        import os, subprocess
        log_dir = Path(os.getenv('APPDATA', '.')) / 'ATS_TicketService' / 'logs'
        log_dir.mkdir(parents=True, exist_ok=True)
        subprocess.Popen(f'explorer "{log_dir}"')

    # ── Task Scheduler ──────────────────────────────────────────────────────

    def _register_task(self):
        try:
            import subprocess, ctypes
            exe    = sys.executable
            script = os.path.abspath(__file__)
            runner = os.path.join(os.path.dirname(script), 'ticket_service_runner.py')
            task_name = 'ATS_TicketService'
            user  = os.environ.get('USERNAME','')
            # pythonw.exe = nessuna finestra console
            pythonw = exe.replace('python.exe','pythonw.exe').replace('python3.exe','pythonw.exe')
            if not os.path.exists(pythonw): pythonw = exe

            # Crea XML task scheduler (più affidabile di schtasks da CLI)
            xml = f'''<?xml version="1.0" encoding="UTF-16"?>
<Task version="1.2" xmlns="http://schemas.microsoft.com/windows/2004/02/mit/task">
  <Triggers>
    <LogonTrigger>
      <Enabled>true</Enabled>
      <Delay>PT2M</Delay>
    </LogonTrigger>
  </Triggers>
  <Principals>
    <Principal id="Author">
      <UserId>{user}</UserId>
      <LogonType>InteractiveToken</LogonType>
      <RunLevel>LeastPrivilege</RunLevel>
    </Principal>
  </Principals>
  <Settings>
    <MultipleInstancesPolicy>IgnoreNew</MultipleInstancesPolicy>
    <DisallowStartIfOnBatteries>false</DisallowStartIfOnBatteries>
    <StopIfGoingOnBatteries>false</StopIfGoingOnBatteries>
    <ExecutionTimeLimit>PT0S</ExecutionTimeLimit>
    <Enabled>true</Enabled>
  </Settings>
  <Actions Context="Author">
    <Exec>
      <Command>{pythonw}</Command>
      <Arguments>"{runner}"</Arguments>
      <WorkingDirectory>{os.path.dirname(script)}</WorkingDirectory>
    </Exec>
  </Actions>
</Task>'''

            # Salva XML temporaneo
            import tempfile
            xml_file = os.path.join(tempfile.gettempdir(), 'ats_ticket_task.xml')
            with open(xml_file, 'w', encoding='utf-16') as f:
                f.write(xml)

            # Esegui come admin tramite ShellExecute (richiede UAC)
            rc = ctypes.windll.shell32.ShellExecuteW(
                None, 'runas', 'schtasks',
                f'/create /tn "{task_name}" /xml "{xml_file}" /f',
                None, 0  # SW_HIDE
            )
            if rc > 32:
                messagebox.showinfo('Task Scheduler',
                    f'✅ Task "{task_name}" registrato!\n\n'
                    f'Il servizio partirà automaticamente al prossimo login.')
            else:
                messagebox.showerror('Errore',
                    f'Registrazione fallita (codice {rc}).\n'
                    f'Prova ad avviare il configuratore come Amministratore.')

        except Exception as e:
            messagebox.showerror('Errore', str(e))

    def _unregister_task(self):
        try:
            import subprocess
            subprocess.run('schtasks /delete /tn "ATS_TicketService" /f', shell=True, check=True)
            messagebox.showinfo('Task Scheduler', 'Task rimosso.')
        except Exception as e:
            messagebox.showerror('Errore', str(e))

    # ── System Tray ─────────────────────────────────────────────────────────

    def _make_tray_icon(self, color: str = '#f97316') -> 'Image':
        """Crea icona tray 64x64 con lettera T e colore stato."""
        img = Image.new('RGBA', (64, 64), (0, 0, 0, 0))
        draw = ImageDraw.Draw(img)
        # Cerchio di sfondo
        draw.ellipse([2, 2, 62, 62], fill=color)
        # Lettera T bianca
        draw.rectangle([20, 18, 44, 24], fill='white')  # barra orizzontale
        draw.rectangle([29, 18, 35, 48], fill='white')  # barra verticale
        return img

    def _setup_tray(self):
        """Inizializza icona system tray."""
        if not HAS_TRAY:
            return
        try:
            icon_img = self._make_tray_icon('#64748b')  # grigio = fermo

            def on_show(icon, item):
                self.after(0, self.deiconify)

            def on_stop(icon, item):
                self.after(0, self._stop_service)

            def on_quit(icon, item):
                self.after(0, self._quit_all)

            menu = pystray.Menu(
                pystray.MenuItem('Apri configuratore', on_show, default=True),
                pystray.MenuItem('Ferma servizio', on_stop),
                pystray.Menu.SEPARATOR,
                pystray.MenuItem('Esci', on_quit),
            )
            self._tray = pystray.Icon('ATS Ticket Service', icon_img,
                                      'ATS Ticket Service — Fermo', menu)
            t = threading.Thread(target=self._tray.run, daemon=True)
            t.start()
        except Exception as e:
            print(f"Tray non disponibile: {e}")
            self._tray = None

    def _update_tray(self, running: bool):
        """Aggiorna colore e tooltip icona tray."""
        if not HAS_TRAY or not hasattr(self, '_tray') or not self._tray:
            return
        try:
            color = '#10b981' if running else '#64748b'
            status = 'In esecuzione ✅' if running else 'Fermo ⏹'
            self._tray.icon  = _make_icon(color)
            self._tray.title = f'ATS Ticket Service — {status}'
        except Exception:
            pass

    def _quit_all(self):
        """Ferma servizio, ferma tray, chiude tutto."""
        self._stop_service()
        tray = getattr(self, '_tray', None)
        self._tray = None
        # Prima destroy() per terminare mainloop
        try:
            self.destroy()
        except Exception:
            pass
        # Poi ferma tray (in thread separato per non bloccare)
        if tray:
            def stop_tray():
                try: tray.stop()
                except Exception: pass
            threading.Thread(target=stop_tray, daemon=True).start()

    def _on_close(self):
        """Chiudi finestra → minimizza in tray se disponibile, altrimenti esce."""
        if HAS_TRAY and hasattr(self, '_tray') and self._tray:
            # Nascondi finestra — il tray continua a girare
            self.withdraw()
        else:
            # Niente tray: chiede conferma se servizio attivo
            if self._service:
                if messagebox.askyesno('Chiudi',
                    'Il servizio è in esecuzione. Fermarlo e uscire?'):
                    self._quit_all()
            else:
                self.destroy()


# ── Entry point ─────────────────────────────────────────────────────────────
def run_with_tray():
    """Avvia il servizio con icona tray ma senza finestra principale."""
    setup_logging(log_callback=print)

    if not HAS_TRAY:
        # Fallback senza tray: loop puro
        svc = TicketService(log_callback=print)
        try:
            svc.run_loop()
        except KeyboardInterrupt:
            svc.stop()
        return

    # Crea icona tray minimale
    try:
        svc = TicketService(log_callback=print)
        svc_thread = None

        def make_icon(color):
            img = Image.new('RGBA', (64, 64), (0,0,0,0))
            draw = ImageDraw.Draw(img)
            draw.ellipse([2,2,62,62], fill=color)
            draw.rectangle([20,18,44,24], fill='white')
            draw.rectangle([29,18,35,48], fill='white')
            return img

        def on_open(icon, item):
            """Apri il configuratore GUI."""
            import subprocess
            subprocess.Popen([sys.executable, __file__])

        def on_quit(icon, item):
            svc.stop()
            icon.stop()

        menu = pystray.Menu(
            pystray.MenuItem('Apri configuratore', on_open),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem('Esci', on_quit),
        )

        icon = pystray.Icon('ATS Ticket Service',
                            make_icon('#10b981'),
                            'ATS Ticket Service — In esecuzione ✅',
                            menu)

        # Avvia servizio in thread separato
        svc_thread = svc.start()

        # Avvia tray (blocca fino a on_quit)
        icon.run()

    except Exception as e:
        print(f"Errore tray service: {e}")
        svc = TicketService(log_callback=print)
        svc.run_loop()


def _make_icon(color='#64748b'):
    img = Image.new('RGBA', (64,64),(0,0,0,0))
    draw = ImageDraw.Draw(img)
    draw.ellipse([2,2,62,62], fill=color)
    draw.rectangle([20,18,44,24], fill='white')
    draw.rectangle([29,18,35,48], fill='white')
    return img


if __name__ == '__main__':
    if '--service' in sys.argv:
        run_with_tray()
    else:
        # Tkinter DEVE girare nel thread principale su Windows
        # Pystray gira in thread secondario daemon
        # Quando la finestra viene nascosta (withdraw), il processo continua
        # perché il thread principale è ancora in mainloop()

        app = TicketGUI()

        if HAS_TRAY:
            try:
                tray_ref = [None]

                def tray_show(icon, item):
                    app.after(0, app.deiconify)
                    app.after(0, lambda: app.state('normal'))

                def tray_quit(icon, item):
                    app.after(0, app._quit_all)

                tray_menu = pystray.Menu(
                    pystray.MenuItem('Apri configuratore', tray_show, default=True),
                    pystray.Menu.SEPARATOR,
                    pystray.MenuItem('Esci', tray_quit),
                )
                tray = pystray.Icon(
                    'ATS Ticket Service',
                    _make_icon('#64748b'),
                    'ATS Ticket Service — Fermo',
                    tray_menu
                )
                tray_ref[0] = tray
                app._tray = tray

                # Pystray in thread daemon — si chiude solo quando il processo esce
                tray_thread = threading.Thread(target=tray.run, daemon=True)
                tray_thread.start()

            except Exception as e:
                print(f"Tray non avviato: {e}")
                app._tray = None

        # Tkinter nel thread principale
        app.mainloop()
        # mainloop() termina solo quando _quit_all() chiama destroy()
        # Se la finestra viene solo nascosta (withdraw), mainloop() continua

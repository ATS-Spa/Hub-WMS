"""
ATS - Backend VLT: FR + RMA in un solo eseguibile.

1) cerca nella posta di oggi l'allegato fr.csv (anche .gz / .bz2)  -> foglio "FR" (prima "Foglio1")
2) cerca nella posta di oggi l'allegato rma.csv (anche .gz / .bz2) -> foglio RMA (default "RMA", creato se manca)
   solo stato TO_SHIP_FROM_CW, esclusa la priorita "Minore" (balancing), un RMA per Id.

Stesso Google Sheet dei FR (SHEET_ID nel config.ini): l'app Easyloader legge il foglio RMA
e aggiorna da sola i "Ritorni in giacenza" (resta possibile l'import manuale del CSV).

Il vecchio config.ini dello script fr funziona cosi com'e: la sezione [EXEC] non serve piu
(il file ACK lo crea l'app) e viene ignorata. Facoltativi nella sezione [GOOGLE]
(se mancano valgono questi):
    FR_SHEET  = FR          FR_GID  = 244367079
    RMA_SHEET = RMA         RMA_GID = 745113444
Il foglio si cerca prima per nome, poi per gid (numero dopo gid= nel link, non cambia rinominando).
"""
import os
import sys
import gzip
import bz2
import time
import subprocess
import configparser
from datetime import datetime

import pandas as pd

try:
    import win32com.client
except ImportError:          # solo per i test fuori da Windows
    win32com = None

# ========================
# 0. Percorsi base
# ========================
if getattr(sys, "frozen", False):
    BASE_DIR = os.path.dirname(os.path.abspath(sys.executable))
else:
    BASE_DIR = os.path.dirname(os.path.abspath(__file__))

CONFIG_FILE = os.path.join(BASE_DIR, "config.ini")

# ========================
# Impostazioni retry Outlook
# ========================
MAX_TENTATIVI_OUTLOOK = 10
ATTESA_TRA_TENTATIVI = 300       # 5 minuti
ATTESA_AVVIO_OUTLOOK = 20        # 20 secondi dopo l'avvio di Outlook

OUTLOOK_EXE = r"C:\Program Files\Microsoft Office\root\Office16\OUTLOOK.EXE"

# ========================
# File da cercare
# ========================
FILE_FR = "fr.csv"
FILE_RMA = "rma.csv"
ESTENSIONI = ("", ".gz", ".bz2")

# colonne del foglio FR (identiche allo script fr di prima)
COLONNE_FR = [
    "fr_id", "f_mat_material", "depot_origine", "f_mat_serial_no", "f_mat_tmpn",
    "awb_cw", "note", "stato", "data_ultima_modifica", "riparatore",
    "data_apertura", "zona", "advanced_swap", "serializzato",
]

# filtro RMA
RMA_STATO = "TO_SHIP_FROM_CW"
RMA_PRIORITA_ESCLUSE = {"MINORE"}

# colonne del foglio RMA: stessi nomi dell'export VLT "Ritorni in giacenza"
# (l'app le legge con la stessa mappa dell'import manuale)
COLONNE_RMA = [
    ("Id", "id_rma"),
    ("Richiedente", "richiedente"),
    ("Data Apertura", "data_apertura"),
    ("Data Ultima Modifica", "data_ultima_modifica"),
    ("Material", "material"),
    ("Equipment", "equipment"),
    ("Stato", "stato"),
    ("Priorita", "priorita"),
    ("Strategia", "strategia"),
    ("Deposito Origine", "depot_origine"),
    ("Deposito Destinazione RMA", "depot_destinazione"),
    ("Deposito Destinazione Indirizzo RMA", "depot_dest_indirizzo"),
    ("Failure Report", "fail_rep_id"),
    ("Awb", "awb"),
]
COLONNA_ESTRATTO = "Estratto Il"

MESI = {"JAN": 1, "FEB": 2, "MAR": 3, "APR": 4, "MAY": 5, "JUN": 6,
        "JUL": 7, "AUG": 8, "SEP": 9, "OCT": 10, "NOV": 11, "DEC": 12,
        "GEN": 1, "MAG": 5, "GIU": 6, "LUG": 7, "AGO": 8, "SET": 9, "OTT": 10, "DIC": 12}


# ========================
# 1. Creazione/lettura config
# ========================
def create_config():
    print("=== Configurazione iniziale ===")
    mailbox = input("Mailbox Outlook (lascia vuoto per default): ").strip()
    folder = input("Cartella Outlook (default: Posta in arrivo): ").strip() or "Posta in arrivo"
    email_from = input("Email a cui mandare gli errori: ").strip()
    sheet_id = input("ID Google Sheet (lo stesso dei FR): ").strip()
    service_json = input("Nome file JSON Service Account (nella stessa cartella dello script): ").strip()

    config = configparser.ConfigParser()
    config["OUTLOOK"] = {
        "MAILBOX_DISPLAY_NAME": mailbox,
        "FOLDER_PATH": folder,
        "EMAIL_FROM": email_from,
    }
    config["GOOGLE"] = {
        "SHEET_ID": sheet_id,
        "SERVICE_ACCOUNT_JSON": service_json,
        "FR_SHEET": "FR",
        "FR_GID": "244367079",
        "RMA_SHEET": "RMA",
        "RMA_GID": "745113444",
    }
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        config.write(f)
    print(f"✅ Config salvato in {CONFIG_FILE}")


def load_config():
    if not os.path.exists(CONFIG_FILE):
        create_config()
    config = configparser.ConfigParser()
    config.read(CONFIG_FILE, encoding="utf-8")
    if "OUTLOOK" not in config or "GOOGLE" not in config:
        print("⚠️ Sezioni [OUTLOOK] / [GOOGLE] mancanti nel config.ini")
        create_config()
        config.read(CONFIG_FILE, encoding="utf-8")
    return config


# ========================
# 2. Mail di errore
# ========================
def send_error_email(subject, body, to_email):
    try:
        outlook = win32com.client.Dispatch("Outlook.Application")
        mail = outlook.CreateItem(0)  # olMailItem
        mail.To = to_email
        mail.Subject = subject
        mail.Body = body
        mail.Send()
        print(f"⚠️ Mail di errore inviata a {to_email}")
    except Exception as e:
        print(f"❌ Impossibile inviare mail di errore: {e}")


# ========================
# 3. Avvio / riattivazione Outlook
# ========================
def open_outlook():
    try:
        if not os.path.exists(OUTLOOK_EXE):
            print("⚠️ Outlook non trovato nel percorso:")
            print(OUTLOOK_EXE)
            return False
        print("📧 Avvio Outlook...")
        subprocess.Popen([OUTLOOK_EXE], stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        print(f"⏳ Attendo {ATTESA_AVVIO_OUTLOOK} secondi per permettere a Outlook di caricarsi...")
        time.sleep(ATTESA_AVVIO_OUTLOOK)
        return True
    except Exception as e:
        print(f"⚠️ Errore durante l'avvio di Outlook: {e}")
        return False


# ========================
# 4. Outlook: cartella e allegati
# ========================
def get_outlook_folder(mailbox_name, folder_path):
    outlook = win32com.client.Dispatch("Outlook.Application").GetNamespace("MAPI")
    if mailbox_name:
        folder = outlook.Folders[mailbox_name]
    else:
        folder = outlook.GetDefaultFolder(6)
    for part in folder_path.split(">"):
        folder = folder.Folders[part.strip()]
    return folder


def nome_corrisponde(att_name, base):
    """fr.csv / fr.csv.gz / fr.csv.bz2 (anche con un prefisso, es. 2026_10_16_fr.csv.gz)."""
    n = att_name.lower().strip()
    return any(n.endswith(base + ext) for ext in ESTENSIONI)


def estrai_allegato(att, base):
    """Salva l'allegato e, se compresso, lo scompatta. Restituisce il percorso del .csv."""
    nome = att.FileName.lower().strip()
    grezzo = os.path.join(BASE_DIR, base.replace(".csv", "") + "_allegato.tmp")
    out = os.path.join(BASE_DIR, base.replace(".csv", "") + "_temp.csv")
    att.SaveAsFile(grezzo)          # SaveAsFile regge anche gli allegati grandi (rma.csv.gz ~ 10 MB)
    scompatta(grezzo, out, nome)
    try:
        os.remove(grezzo)
    except OSError:
        pass
    return out


def scompatta(src, dst, nome):
    if nome.endswith(".gz"):
        with gzip.open(src, "rb") as f_in, open(dst, "wb") as f_out:
            while True:
                b = f_in.read(1 << 20)
                if not b:
                    break
                f_out.write(b)
    elif nome.endswith(".bz2"):
        with bz2.open(src, "rb") as f_in, open(dst, "wb") as f_out:
            while True:
                b = f_in.read(1 << 20)
                if not b:
                    break
                f_out.write(b)
    else:
        with open(src, "rb") as f_in, open(dst, "wb") as f_out:
            f_out.write(f_in.read())


def cerca_allegati(mancanti):
    """
    Una passata sulla posta di oggi (dalla piu recente): per ogni file in `mancanti`
    restituisce { base: (percorso_csv, ora_ricezione) } per quelli trovati.
    """
    trovati = {}
    try:
        folder = get_outlook_folder(MAILBOX_NAME, FOLDER_PATH)
    except Exception as e:
        print(f"⚠️ Impossibile aprire la cartella Outlook: {e}")
        return trovati
    try:
        messages = folder.Items
        messages.Sort("[ReceivedTime]", True)
        today = datetime.now().date()
        for msg in messages:
            if len(trovati) == len(mancanti):
                break
            try:
                ricevuta = getattr(msg, "ReceivedTime", None)
                if ricevuta is None:
                    continue    # avvisi di mancato recapito, inviti ecc.: non sono mail con allegati da leggere
                if ricevuta.date() != today:
                    # ordinati dal piu recente: superato oggi non serve continuare
                    if ricevuta.date() < today:
                        break
                    continue
                attachments = getattr(msg, "Attachments", None)
                if not attachments or attachments.Count == 0:
                    continue
                for i in range(1, attachments.Count + 1):
                    att = attachments.Item(i)
                    for base in mancanti:
                        if base in trovati or not nome_corrisponde(att.FileName, base):
                            continue
                        path = estrai_allegato(att, base)
                        trovati[base] = (path, ricevuta.strftime("%Y-%m-%d %H:%M"))
                        print(f"✅ Allegato {att.FileName} estratto: {path}")
            except Exception as e:
                print(f"⚠️ Errore con mail '{getattr(msg, 'Subject', '')}': {e}")
                continue
    except Exception as e:
        print(f"⚠️ Errore durante la lettura delle mail Outlook: {e}")
    return trovati


# ========================
# 5. Lettura e filtro dei CSV
# ========================
def leggi_fr(csv_path):
    df = pd.read_csv(
        csv_path, sep="|", dtype=str, keep_default_na=False, quoting=3,
        engine="python", on_bad_lines="warn", usecols=range(57),
    )
    df.columns = [c.strip() for c in df.columns]
    df = df[COLONNE_FR].astype(str)
    df = df[df["fr_id"].str.strip().str.isdigit()]
    df["fr_id"] = df["fr_id"].str.strip().astype(int)
    df = df.sort_values(by="fr_id", ascending=False)
    return [df.columns.tolist()] + df.values.tolist()


def data_vlt(v):
    """14-OCT-26 -> 14.10.2026 (formato dell'export VLT, che l'app gia legge). Altrimenti invariata."""
    v = (v or "").strip()
    p = v.split("-")
    if len(p) == 3 and p[1].upper() in MESI and p[0].isdigit() and p[2].isdigit():
        anno = int(p[2])
        if anno < 100:
            anno += 2000
        return f"{int(p[0]):02d}.{MESI[p[1].upper()]:02d}.{anno}"
    return v


def apri_testo(path):
    """utf-8 se valido, altrimenti windows-1252 (accenti negli indirizzi)."""
    try:
        with open(path, "r", encoding="utf-8") as f:
            for _ in f:
                pass
        return open(path, "r", encoding="utf-8", newline="")
    except UnicodeDecodeError:
        return open(path, "r", encoding="cp1252", errors="replace", newline="")


def leggi_rma(csv_path, estratto_il):
    """
    rma.csv e lo storico completo (centinaia di migliaia di righe): lo leggo riga per riga
    e tengo solo TO_SHIP_FROM_CW non "Minore". Un RMA per Id (nel file alcuni sono ripetuti).
    """
    per_id = {}
    scartate = 0
    with apri_testo(csv_path) as f:
        header = [h.strip().lower() for h in f.readline().rstrip("\r\n").split("|")]
        n = len(header)
        pos = {h: i for i, h in enumerate(header)}
        manc = [c for _, c in COLONNE_RMA if c not in pos] + [c for c in ("stato",) if c not in pos]
        if manc:
            raise Exception("Colonne mancanti in rma.csv: " + ", ".join(manc) + "\nTrovate: " + " | ".join(header))
        i_ind = pos["depot_dest_indirizzo"]
        for riga in f:
            parti = riga.rstrip("\r\n").split("|")
            if len(parti) > n:
                # un "|" dentro l'indirizzo: riunisco le parti in eccesso nel campo indirizzo
                extra = len(parti) - n
                parti = parti[:i_ind] + ["|".join(parti[i_ind:i_ind + extra + 1])] + parti[i_ind + extra + 1:]
            if len(parti) < n:
                parti += [""] * (n - len(parti))
            r = {h: parti[i].strip() for h, i in pos.items()}
            if r["stato"].upper() != RMA_STATO:
                continue
            if r.get("priorita", "").upper() in RMA_PRIORITA_ESCLUSE:
                scartate += 1
                continue
            idr = r["id_rma"].replace(".0", "") if r["id_rma"].endswith(".0") else r["id_rma"]
            if not idr.isdigit():
                continue
            r["id_rma"] = idr
            per_id[idr] = r
    righe = []
    for idr in sorted(per_id, key=int, reverse=True):
        r = per_id[idr]
        o = []
        for _, c in COLONNE_RMA:
            v = r.get(c, "")
            if c in ("data_apertura", "data_ultima_modifica"):
                v = data_vlt(v)
            o.append(v)
        righe.append(o + [estratto_il])
    valori = [[h for h, _ in COLONNE_RMA] + [COLONNA_ESTRATTO]] + righe
    if not righe:
        # nessun ritorno oggi: lascio comunque la data di estrazione, cosi l'app sa che il file e arrivato
        valori.append([""] * len(COLONNE_RMA) + [estratto_il])
    print(f"ℹ️ RMA {RMA_STATO}: {len(righe)} (escluse {scartate} righe 'Minore')")
    return valori, len(righe)


# ========================
# 6. Google Sheet
# ========================
TIMEOUT_GOOGLE = 180    # secondi: una chiamata a Google che non risponde viene interrotta e riprovata


def servizio_google():
    from google.oauth2.service_account import Credentials
    from googleapiclient.discovery import build
    import httplib2
    import google_auth_httplib2
    creds = Credentials.from_service_account_file(
        SERVICE_JSON, scopes=["https://www.googleapis.com/auth/spreadsheets"])
    # senza timeout una connessione caduta resta appesa per sempre
    http = google_auth_httplib2.AuthorizedHttp(creds, http=httplib2.Http(timeout=TIMEOUT_GOOGLE))
    return build("sheets", "v4", http=http, cache_discovery=False).spreadsheets()


def errore_temporaneo(e):
    s = str(e).lower()
    return (isinstance(e, (TimeoutError, ConnectionError, OSError))
            or any(k in s for k in ("timed out", "timeout", "502", "500", "503", "429", "internal error",
                                    "rate limit", "connection", "reset", "broken pipe", "ssl")))


def con_retry(fn, scadenza):
    attesa = 5
    while True:
        try:
            return fn()
        except Exception as e:
            if errore_temporaneo(e) and time.time() < scadenza:
                print(f"⚠️ Errore temporaneo Google ({e.__class__.__name__}), riprovo tra {attesa} secondi...")
                time.sleep(attesa)
                attesa = min(attesa * 2, 300)
                continue
            raise


def q(nome):
    return "'" + nome.replace("'", "''") + "'"


def trova_foglio(nome, gid, riserva, crea, scadenza):
    """
    Nome reale del foglio: prima per nome, poi per gid (il numero dopo gid= nel link,
    che non cambia se rinomini il foglio), poi il nome di riserva. Se non c'e e crea=True lo crea.
    """
    meta = con_retry(lambda: servizio_google().get(
        spreadsheetId=SHEET_ID, fields="sheets.properties(sheetId,title)").execute(), scadenza)
    fogli = [(s["properties"]["title"], str(s["properties"]["sheetId"])) for s in meta.get("sheets", [])]
    titoli = [t for t, _ in fogli]
    if nome in titoli:
        return nome
    per_gid = [t for t, g in fogli if gid and g == str(gid).strip()]
    if per_gid:
        print(f"ℹ️ Foglio '{nome}' non trovato: uso '{per_gid[0]}' (gid {gid})")
        return per_gid[0]
    if riserva and riserva in titoli:
        print(f"ℹ️ Foglio '{nome}' non trovato: uso '{riserva}'")
        return riserva
    if not crea:
        raise Exception(f"Foglio '{nome}' (gid {gid}) non trovato. Fogli presenti: {', '.join(titoli)}")
    con_retry(lambda: servizio_google().batchUpdate(
        spreadsheetId=SHEET_ID,
        body={"requests": [{"addSheet": {"properties": {"title": nome}}}]}).execute(), scadenza)
    print(f"✅ Creato il foglio '{nome}'")
    return nome


def scrivi_foglio(nome, gid, valori, riserva="", crea=False):
    """Scrive a blocchi da 5000 righe dalla A1 e poi pulisce le righe vecchie oltre la fine."""
    DIMENSIONE_BATCH = 5000
    scadenza = time.time() + 600     # 10 minuti come prima
    nome = trova_foglio(nome, gid, riserva, crea, scadenza)
    tot = len(valori)
    inviate = 0
    while inviate < tot:
        fine = min(inviate + DIMENSIONE_BATCH, tot)
        blocco = valori[inviate:fine]
        rng = f"{q(nome)}!A{inviate + 1}"
        con_retry(lambda: servizio_google().values().update(
            spreadsheetId=SHEET_ID, range=rng, valueInputOption="RAW",
            body={"values": blocco}).execute(), scadenza)
        inviate = fine
        print(f"✅ {nome}: righe {inviate - len(blocco) + 1}-{inviate} di {tot}")
    # righe rimaste da un file piu lungo del giorno prima
    con_retry(lambda: servizio_google().values().clear(
        spreadsheetId=SHEET_ID, range=f"{q(nome)}!A{tot + 1}:ZZ", body={}).execute(), scadenza)
    print(f"✅ {nome}: caricamento completato ({tot - 1} righe)")


# ========================
# MAIN
# ========================
def elabora(base, path, ricevuta):
    if base == FILE_FR:
        scrivi_foglio(FR_SHEET, FR_GID, leggi_fr(path), riserva="Foglio1")
    else:
        valori, n = leggi_rma(path, ricevuta)
        scrivi_foglio(RMA_SHEET, RMA_GID, valori, crea=True)


def main():
    da_fare = [FILE_FR, FILE_RMA]     # prima i FR, poi gli RMA
    fatti, errori = [], []

    print("")
    print("==============================================")
    print("🔎 RICERCA ALLEGATI " + " + ".join(da_fare).upper())
    print("==============================================")
    print(f"Numero massimo tentativi: {MAX_TENTATIVI_OUTLOOK}")
    print(f"Intervallo tra tentativi: {ATTESA_TRA_TENTATIVI // 60} minuti")

    for tentativo in range(1, MAX_TENTATIVI_OUTLOOK + 1):
        print("")
        print("==============================================")
        print(f"📧 TENTATIVO {tentativo} DI {MAX_TENTATIVI_OUTLOOK} · cerco: {', '.join(da_fare)}")
        print("==============================================")
        if not open_outlook():
            print("⚠️ Impossibile verificare correttamente l'avvio di Outlook.")

        trovati = cerca_allegati(da_fare)
        for base in [b for b in (FILE_FR, FILE_RMA) if b in trovati]:
            path, ricevuta = trovati[base]
            try:
                elabora(base, path, ricevuta)
                fatti.append(base)
            except Exception as e:
                msg = f"❌ Errore durante il caricamento di {base} su Google Sheet: {e}"
                print(msg)
                errori.append(msg)
            da_fare.remove(base)       # trovato: anche se il caricamento fallisce non lo riprovo all'infinito

        if not da_fare:
            break
        if tentativo < MAX_TENTATIVI_OUTLOOK:
            print(f"⏳ Non ancora arrivati: {', '.join(da_fare)}. Attendo {ATTESA_TRA_TENTATIVI // 60} minuti...")
            time.sleep(ATTESA_TRA_TENTATIVI)

    for base in da_fare:
        errori.append(
            f"Allegato {base} non trovato nella posta di oggi.\n"
            f"Sono stati effettuati {MAX_TENTATIVI_OUTLOOK} tentativi "
            f"(ogni {ATTESA_TRA_TENTATIVI // 60} minuti).")

    print("")
    print("==============================================")
    print("✅ Caricati: " + (", ".join(fatti) or "nessuno"))
    if errori:
        print("❌ Problemi:\n" + "\n".join(errori))
        send_error_email("Errore script FR/RMA", "\n\n".join(errori), EMAIL_FROM)
    print("==============================================")


def blocca_selezione_console():
    """
    Windows: un clic dentro la finestra nera la mette in "Seleziona" e il programma si ferma
    finche non premi Invio/Esc. Tolgo la Modifica rapida solo per questa finestra.
    """
    if os.name != "nt":
        return
    try:
        import ctypes
        k = ctypes.windll.kernel32
        h = k.GetStdHandle(-10)                 # STD_INPUT_HANDLE
        modo = ctypes.c_uint32()
        if k.GetConsoleMode(h, ctypes.byref(modo)):
            # via ENABLE_QUICK_EDIT_MODE (0x40), con ENABLE_EXTENDED_FLAGS (0x80)
            k.SetConsoleMode(h, (modo.value & ~0x40) | 0x80)
    except Exception:
        pass


if __name__ == "__main__":
    blocca_selezione_console()
    config = load_config()
    MAILBOX_NAME = config["OUTLOOK"].get("MAILBOX_DISPLAY_NAME", "")
    FOLDER_PATH = config["OUTLOOK"].get("FOLDER_PATH", "Posta in arrivo")
    EMAIL_FROM = config["OUTLOOK"]["EMAIL_FROM"]
    SHEET_ID = config["GOOGLE"]["SHEET_ID"]
    SERVICE_JSON = os.path.join(BASE_DIR, config["GOOGLE"]["SERVICE_ACCOUNT_JSON"])
    FR_SHEET = config["GOOGLE"].get("FR_SHEET", "FR").strip() or "FR"
    FR_GID = config["GOOGLE"].get("FR_GID", "244367079").strip()
    RMA_SHEET = config["GOOGLE"].get("RMA_SHEET", "RMA").strip() or "RMA"
    RMA_GID = config["GOOGLE"].get("RMA_GID", "745113444").strip()
    try:
        main()
    except Exception as e:
        try:
            send_error_email("Errore script FR/RMA", f"Errore esecuzione script:\n{e}", EMAIL_FROM)
        except Exception:
            pass
        raise
